import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

// Auth0 ACUL requires a single self-contained JS bundle.
// preview.html is a dev-only second entry for local screen previews.
const CDN_BASE_URL = process.env.CDN_BASE_URL ?? ''
const CDN_PATH_PREFIX = process.env.CDN_PATH_PREFIX ?? 'toyota-acul'
const assetBase = CDN_BASE_URL ? `${CDN_BASE_URL}/${CDN_PATH_PREFIX}/` : '/'

export default defineConfig({
  plugins: [react()],
  base: assetBase,
  build: {
    modulePreload: { polyfill: false },
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        preview: resolve(__dirname, 'preview.html'),
      },
      output: {
        // Single chunk — no code splitting for ACUL
        manualChunks: undefined,
        entryFileNames: (chunkInfo) => chunkInfo.name === 'preview' ? 'preview.[hash].js' : 'acul.[hash].js',
        chunkFileNames: 'acul.[hash].js',
        assetFileNames: (assetInfo) => {
          const name = assetInfo.names?.[0] ?? ''
          return name.includes('preview') ? 'preview.[hash].[ext]' : 'acul.[hash].[ext]'
        },
      },
    },
  },
})
