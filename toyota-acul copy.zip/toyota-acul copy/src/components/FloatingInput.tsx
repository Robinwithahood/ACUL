import { useState } from 'react'
import './FloatingInput.css'

interface Props {
  id: string
  label: string
  type?: string
  value: string
  onChange: (v: string) => void
  autoComplete?: string
  error?: string
  disabled?: boolean
  variant?: 'box' | 'underline'
  prefix?: string
  showToggle?: boolean
  required?: boolean
}

export default function FloatingInput({
  id, label, type = 'text', value, onChange, autoComplete, error, disabled,
  variant = 'box', prefix, showToggle, required,
}: Props) {
  const [focused, setFocused] = useState(false)
  const [showPw, setShowPw] = useState(false)
  const lifted = focused || value.length > 0
  const inputType = showToggle ? (showPw ? 'text' : 'password') : type
  const isUnderline = variant === 'underline'

  return (
    <div className={`fi-wrap ${isUnderline ? 'fi-wrap--underline' : ''} ${error ? 'fi-wrap--error' : ''}`}>
      <div className={prefix ? 'fi-prefix-row' : undefined}>
        {prefix && <span className="fi-prefix">{prefix}</span>}
        <input
          id={id}
          className="fi-input"
          type={inputType}
          value={value}
          autoComplete={autoComplete}
          disabled={disabled}
          required={required}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          aria-describedby={error ? `${id}-error` : undefined}
          aria-invalid={!!error}
        />
        {showToggle && (
          <button type="button" className="fi-toggle" onClick={() => setShowPw(p => !p)} tabIndex={-1} aria-label={showPw ? 'Hide password' : 'Show password'}>
            {showPw ? <EyeOffIcon /> : <EyeIcon />}
          </button>
        )}
      </div>
      <label
        htmlFor={id}
        className={`fi-label ${lifted ? 'fi-label--lifted' : ''} ${focused ? 'fi-label--focused' : ''}`}
      >
        {label}{required && <span className="fi-required">*</span>}
      </label>
      {error && (
        <span id={`${id}-error`} className="fi-error" role="alert">
          {error}
        </span>
      )}
    </div>
  )
}

function EyeIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  )
}

function EyeOffIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94"/>
      <path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/>
      <line x1="1" y1="1" x2="23" y2="23"/>
    </svg>
  )
}
