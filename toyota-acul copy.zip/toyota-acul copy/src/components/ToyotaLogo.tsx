export default function ToyotaLogo() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 48 }}>
      <img
        src="https://toyota-acul.s3.us-west-1.amazonaws.com/toyota-acul/static/Toyota-Logo.svg"
        alt="Toyota"
        style={{ height: 33, width: 'auto', objectFit: 'contain' }}
      />
    </div>
  )
}
