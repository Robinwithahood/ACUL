import './LoadingOverlay.css'

export default function LoadingOverlay() {
  return (
    <div className="loading-overlay">
      <div className="loading-dots">
        <span />
        <span />
        <span />
      </div>
      <p className="loading-text">LOADING</p>
    </div>
  )
}
