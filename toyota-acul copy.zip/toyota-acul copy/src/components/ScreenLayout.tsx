import type { ReactNode } from 'react'
import ToyotaLogo from './ToyotaLogo'
import './ScreenLayout.css'

interface Props {
  title: string
  left: ReactNode
  right: ReactNode
  footer?: ReactNode
}

export default function ScreenLayout({ title, left, right, footer }: Props) {
  return (
    <div className="sl-page">
      <div className="sl-container">
        <ToyotaLogo />
        <h1 className="sl-title">{title}</h1>

        <div className="sl-body">
          <div className="sl-left">{left}</div>

          <div className="sl-divider" aria-hidden="true">
            <span className="sl-divider-label">or</span>
          </div>

          <div className="sl-right">{right}</div>
        </div>

        {footer && <div className="sl-footer">{footer}</div>}
      </div>
    </div>
  )
}
