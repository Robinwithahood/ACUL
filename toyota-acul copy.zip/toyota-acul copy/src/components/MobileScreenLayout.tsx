import type { ReactNode } from 'react'
import ToyotaLogo from './ToyotaLogo'
import './MobileScreenLayout.css'

interface Props {
  title: string
  content: ReactNode
  footer?: ReactNode
  heroImage?: string
}

export default function MobileScreenLayout({ title, content, footer, heroImage }: Props) {
  return (
    <div className="msl-page">
      {heroImage && (
        <div className="msl-hero" style={{ backgroundImage: `url(${heroImage})` }} />
      )}
      <div className={`msl-container ${heroImage ? 'msl-container--hero' : ''}`}>
        {!heroImage && <ToyotaLogo />}
        <h1 className="msl-title">{title}</h1>

        <div className="msl-body">
          {content}
        </div>

        {footer && <div className="msl-footer">{footer}</div>}
      </div>
    </div>
  )
}
