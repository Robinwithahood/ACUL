const MOBILE_APP_CLIENT_ID = 'POgn891yL6sFM46KprQ3K5Vgi3RwM6IH'

export function isMobileAppLogin(): boolean {
  const clientId = (window as any).universal_login_context?.client?.id
  if (clientId === MOBILE_APP_CLIENT_ID) return true
  // Fallback: treat narrow viewports as mobile (phone/simulator)
  return window.innerWidth <= 600
}
