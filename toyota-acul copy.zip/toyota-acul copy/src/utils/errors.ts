/** Shown for client-side validation failures that are not sourced from Auth0. */
export const CLIENT_ERR = 'Something went wrong. [ISNAUTH]'
