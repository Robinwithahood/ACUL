/**
 * Masks all but the first three digits of a phone number.
 * e.g. "+17785331389" → "+177********"
 *      "17785331389"  → "177********"
 */
export function maskPhone(phone: string): string {
  const prefix = phone.startsWith('+') ? '+' : ''
  const digits = phone.replace(/\D/g, '')
  if (digits.length <= 3) return phone
  return `${prefix}${digits.slice(0, 3)}${'*'.repeat(digits.length - 3)}`
}
