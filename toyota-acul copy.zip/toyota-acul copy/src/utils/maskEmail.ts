/**
 * Masks an email address, keeping the first 3 chars of the local part visible.
 * e.g. "binary@icloud.com" → "bin**********@icloud.com"
 *      "ab@example.com"   → "ab*@example.com"
 */
export function maskEmail(email: string): string {
  const atIndex = email.indexOf('@')
  if (atIndex < 0) return email
  const local = email.slice(0, atIndex)
  const domain = email.slice(atIndex)
  const visible = local.slice(0, Math.min(3, local.length))
  const masked = '*'.repeat(Math.max(local.length - visible.length, 1))
  return `${visible}${masked}${domain}`
}
