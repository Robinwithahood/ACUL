import { useState } from 'react'
import { mockContexts } from './mock-context'
import LoginIdScreen from '../screens/LoginId'
import LoginPasswordScreen from '../screens/LoginPassword'
import SignupIdScreen from '../screens/SignupId'
import SignupPasswordScreen from '../screens/SignupPassword'
import EmailIdentifierChallengeScreen from '../screens/EmailIdentifierChallenge'
import PhoneIdentifierChallengeScreen from '../screens/PhoneIdentifierChallenge'
import '../index.css'
import './PreviewApp.css'

const SCREENS = [
  'login-id', 'login-id-mobile',
  'login-password', 'login-password-mobile',
  'signup-id', 'signup-id-mobile',
  'signup-password', 'signup-password-mobile',
  'email-challenge', 'email-challenge-mobile',
  'phone-challenge', 'phone-challenge-mobile',
] as const
type Screen = typeof SCREENS[number]

const isMobileTab = (s: Screen) => s.endsWith('-mobile')

function setContext(screen: Screen) {
  const ctx = mockContexts[screen] ?? mockContexts['login-id']
  ;(window as any).universal_login_context = ctx
}

export default function PreviewApp() {
  const initial = (new URLSearchParams(location.search).get('screen') as Screen) ?? 'login-id'
  // Set context synchronously before first render
  setContext(initial)
  const [active, setActive] = useState<Screen>(initial)

  function switchTab(s: Screen) {
    setContext(s)
    setActive(s)
  }

  const mobile = isMobileTab(active)

  return (
    <div className="preview-shell">
      <div className="preview-bar">
        <span className="preview-bar-label">Screen Preview</span>
        <div className="preview-bar-tabs">
          {SCREENS.map(s => (
            <button
              key={s}
              className={`preview-tab ${active === s ? 'preview-tab--active' : ''}`}
              onClick={() => switchTab(s)}
            >
              {s}
            </button>
          ))}
        </div>
      </div>
      <div className="preview-frame">
        {/* key forces full remount so managers re-read the new context */}
        {(active === 'login-id' || active === 'login-id-mobile') &&
          <LoginIdScreen key={active} isMobile={mobile} />}
        {(active === 'login-password' || active === 'login-password-mobile') &&
          <LoginPasswordScreen key={active} isMobile={mobile} />}
        {(active === 'signup-id' || active === 'signup-id-mobile') &&
          <SignupIdScreen key={active} isMobile={mobile} />}
        {(active === 'signup-password' || active === 'signup-password-mobile') &&
          <SignupPasswordScreen key={active} isMobile={mobile} />}
        {(active === 'email-challenge' || active === 'email-challenge-mobile') &&
          <EmailIdentifierChallengeScreen key={active} isMobile={mobile} />}
        {(active === 'phone-challenge' || active === 'phone-challenge-mobile') &&
          <PhoneIdentifierChallengeScreen key={active} isMobile={mobile} />}
      </div>
    </div>
  )
}
