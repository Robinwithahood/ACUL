// Minimal mock of window.universal_login_context for local preview.
// Mirrors the shape Auth0 injects before the ACUL bundle runs.

const base = {
  branding: {
    settings: {
      colors: { primary: '#EB0A1E', page_background: '#ffffff' },
      favicon_url: '',
      logo_url: '',
      font: { url: '' },
    },
  },
  tenant: {
    name: 'Toyota (Preview)',
    friendly_name: 'Toyota',
    enabled_locales: ['en'],
  },
  client: {
    id: 'cjP1mzSnNeudK6VWsCR7Knxi3r5K6Bb8',
    name: 'Toyota SPA',
    logo_url: '',
    description: '',
    metadata: {},
  },
  prompt: { name: 'login' },
  organization: null,
  user: null,
  untrusted_data: {
    submitted_form_data: null,
    authorization_params: { login_hint: '', ui_locales: 'en' },
  },
}

const transaction = {
  state: 'mock-state-preview',
  locale: 'en',
  errors: [],
  connection: {
    name: 'Username-Password-Authentication',
    strategy: 'auth0',
    options: {
      signup_enabled: true,
      forgot_password_enabled: true,
      username_required: false,
      password_policy: 'good',
    },
  },
  alternate_connections: [
    { name: 'google-oauth2', strategy: 'google-oauth2', icon_url: '' },
    { name: 'facebook',      strategy: 'facebook',      icon_url: '' },
    { name: 'apple',         strategy: 'apple',         icon_url: '' },
  ],
  isSignupEnabled: true,
  isForgotPasswordEnabled: true,
  isPasskeyEnabled: false,
}

const mobileBase = {
  ...base,
  client: {
    ...base.client,
    id: 'POgn891yL6sFM46KprQ3K5Vgi3RwM6IH',
  },
}

export const mockContexts: Record<string, object> = {
  'login-id': {
    ...base,
    prompt: { name: 'login-id' },
    screen: {
      name: 'login-id',
      data: null,
      signupLink: '#signup',
      resetPasswordLink: '#reset',
      publicKey: null,
    },
    transaction: {
      ...transaction,
      allowedIdentifiers: ['email'],
      isUsernameRequired: false,
      showPasskeyAutofill: false,
      usernamePolicy: null,
    },
  },

  'login-id-mobile': {
    ...mobileBase,
    prompt: { name: 'login-id' },
    screen: {
      name: 'login-id',
      data: null,
      signupLink: '#signup',
      resetPasswordLink: '#reset',
      publicKey: null,
    },
    transaction: {
      ...transaction,
      allowedIdentifiers: ['email'],
      isUsernameRequired: false,
      showPasskeyAutofill: false,
      usernamePolicy: null,
    },
  },

  'login-password': {
    ...base,
    prompt: { name: 'login-password' },
    screen: {
      name: 'login-password',
      data: { username: 'demo@toyota.com' },
      signupLink: '#signup',
      resetPasswordLink: '#reset',
      editIdentifierLink: '#edit',
    },
    transaction: {
      ...transaction,
      passwordPolicy: 'good',
    },
  },

  'login-password-mobile': {
    ...mobileBase,
    prompt: { name: 'login-password' },
    screen: {
      name: 'login-password',
      data: { username: 'demo@toyota.com' },
      signupLink: '#signup',
      resetPasswordLink: '#reset',
      editIdentifierLink: '#edit',
    },
    transaction: {
      ...transaction,
      passwordPolicy: 'good',
    },
  },

  signup: {
    ...base,
    prompt: { name: 'signup' },
    screen: {
      name: 'signup',
      data: null,
      signupLink: null,
      resetPasswordLink: null,
    },
    transaction: {
      ...transaction,
      passwordComplexityOptions: {
        min_length: 8,
      },
    },
  },

  'signup-mobile': {
    ...mobileBase,
    prompt: { name: 'signup' },
    screen: {
      name: 'signup',
      data: null,
      signupLink: null,
      resetPasswordLink: null,
    },
    transaction: {
      ...transaction,
      passwordComplexityOptions: { min_length: 8 },
    },
  },

  'signup-id': {
    ...base,
    prompt: { name: 'signup-id' },
    screen: {
      name: 'signup-id',
      data: null,
      loginLink: '#login',
    },
    transaction: {
      ...transaction,
      passwordComplexityOptions: { min_length: 8 },
    },
  },

  'signup-id-mobile': {
    ...mobileBase,
    prompt: { name: 'signup-id' },
    screen: {
      name: 'signup-id',
      data: null,
      loginLink: '#login',
    },
    transaction: {
      ...transaction,
      passwordComplexityOptions: { min_length: 8 },
    },
  },

  'signup-password': {
    ...base,
    prompt: { name: 'signup-password' },
    screen: {
      name: 'signup-password',
      data: { email: 'demo@toyota.com', phoneNumber: '+15551234567' },
    },
    transaction: {
      ...transaction,
      passwordComplexityOptions: { min_length: 8 },
    },
  },

  'signup-password-mobile': {
    ...mobileBase,
    prompt: { name: 'signup-password' },
    screen: {
      name: 'signup-password',
      data: { email: 'demo@toyota.com', phoneNumber: '+15551234567' },
    },
    transaction: {
      ...transaction,
      passwordComplexityOptions: { min_length: 8 },
    },
  },

  'email-challenge': {
    ...base,
    prompt: { name: 'email-identifier-challenge' },
    screen: {
      name: 'email-identifier-challenge',
      data: { email: 'demo@toyota.com' },
    },
    transaction: { ...transaction },
  },

  'email-challenge-mobile': {
    ...mobileBase,
    prompt: { name: 'email-identifier-challenge' },
    screen: {
      name: 'email-identifier-challenge',
      data: { email: 'demo@toyota.com' },
    },
    transaction: { ...transaction },
  },

  'phone-challenge': {
    ...base,
    prompt: { name: 'login-passwordless-sms-otp' },
    screen: {
      name: 'login-passwordless-sms-otp',
      data: {
        username: 'testuser1@yopmail.com',
        phone_number: '(619) 572-1975',
        message_type: 'sms',
        show_link_sms: true,
        show_link_voice: false,
      },
    },
    transaction: {
      ...transaction,
      params: {
        client_id: 'preview-client',
        redirect_uri: 'https://example.com/callback',
        response_type: 'code',
        scope: 'openid profile email',
      },
    },
  },

  'phone-challenge-mobile': {
    ...mobileBase,
    prompt: { name: 'login-passwordless-sms-otp' },
    screen: {
      name: 'login-passwordless-sms-otp',
      data: {
        username: 'testuser1@yopmail.com',
        phone_number: '(619) 572-1975',
        message_type: 'sms',
        show_link_sms: true,
        show_link_voice: false,
      },
    },
    transaction: {
      ...transaction,
      params: {
        client_id: 'preview-client',
        redirect_uri: 'https://example.com/callback',
        response_type: 'code',
        scope: 'openid profile email',
      },
    },
  },
}
