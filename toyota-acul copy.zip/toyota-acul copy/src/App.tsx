import LoginIdScreen from './screens/LoginId'
import LoginPasswordScreen from './screens/LoginPassword'
import SignupScreen from './screens/SignupId'
import SignupPasswordScreen from './screens/SignupPassword'
import EmailIdentifierChallengeScreen from './screens/EmailIdentifierChallenge'
import PhoneIdentifierChallengeScreen from './screens/PhoneIdentifierChallenge'
import PhoneChallengeScreen from './screens/PhoneChallenge'
import MfaSmsChallengeScreen from './screens/MfaSmsChallenge'
import MfaSmsEnrollmentScreen from './screens/MfaSmsEnrollment'
import MfaLoginOptionsScreen from './screens/MfaLoginOptions'
import MfaEmailChallengeScreen from './screens/MfaEmailChallenge'
import MfaPhoneChallengeScreen from './screens/MfaPhoneChallenge'
import ResetPasswordRequestScreen from './screens/ResetPasswordRequest'
import ResetPasswordEmailScreen from './screens/ResetPasswordEmail'
import ResetPasswordNewScreen from './screens/ResetPasswordNew'
import ResetPasswordErrorScreen from './screens/ResetPasswordError'
import ResetPasswordSuccessScreen from './screens/ResetPasswordSuccess'
import BruteForceUnblockScreen from './screens/BruteForceUnblock'
import BruteForceUnblockSuccessScreen from './screens/BruteForceUnblockSuccess'
import { isMobileAppLogin } from './utils/deviceDetection'

function App() {
  // Read after mount() has called extractContext(), not at module-load time.
  const screenName = (window as any).universal_login_context?.screen?.name ?? ''
  const isMobile = isMobileAppLogin()

  if (screenName === 'login-id') return <LoginIdScreen isMobile={isMobile} />
  if (screenName === 'login-password') return <LoginPasswordScreen isMobile={isMobile} />
  if (screenName === 'signup-id') return <SignupScreen isMobile={isMobile} />
  if (screenName === 'signup-password') return <SignupPasswordScreen isMobile={isMobile} />
  if (screenName === 'email-identifier-challenge') return <EmailIdentifierChallengeScreen isMobile={isMobile} />
  if (screenName === 'login-passwordless-sms-otp' || screenName === 'passwordless-sms-challenge') return <PhoneIdentifierChallengeScreen isMobile={isMobile} />
  if (screenName === 'phone-identifier-challenge') return <PhoneChallengeScreen isMobile={isMobile} />
  if (screenName === 'mfa-sms-challenge') return <MfaSmsChallengeScreen isMobile={isMobile} />
  if (screenName === 'mfa-sms-enrollment') return <MfaSmsEnrollmentScreen isMobile={isMobile} />
  if (screenName === 'mfa-login-options') return <MfaLoginOptionsScreen isMobile={isMobile} />
  if (screenName === 'mfa-email-challenge') return <MfaEmailChallengeScreen isMobile={isMobile} />
  if (screenName === 'mfa-phone-challenge') return <MfaPhoneChallengeScreen isMobile={isMobile} />
  if (screenName === 'reset-password-request') return <ResetPasswordRequestScreen isMobile={isMobile} />
  if (screenName === 'reset-password-email') return <ResetPasswordEmailScreen isMobile={isMobile} />
  if (screenName === 'reset-password') return <ResetPasswordNewScreen isMobile={isMobile} />
  if (screenName === 'reset-password-error') return <ResetPasswordErrorScreen isMobile={isMobile} />
  if (screenName === 'reset-password-success') return <ResetPasswordSuccessScreen isMobile={isMobile} />
  if (screenName === 'brute-force-protection-unblock') return <BruteForceUnblockScreen isMobile={isMobile} />
  if (screenName === 'brute-force-protection-unblock-success') return <BruteForceUnblockSuccessScreen isMobile={isMobile} />

  // Fallback: shown only during local dev where no Auth0 context exists
  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif', color: '#666' }}>
      <strong>ACUL Dev Mode</strong>
      <p>No Auth0 <code>universal_login_context</code> detected.</p>
      <p>Current screen: <code>{screenName || '(none)'}</code></p>
      <p>Deploy this bundle to Auth0 to test the full flow.</p>
    </div>
  )
}

export default App
