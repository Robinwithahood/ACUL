import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'

// Auth0 injects universal_login_context via an inline script which may be
// blocked by CSP. If so, we extract and decode it from the DOM ourselves.
function extractContext() {
  if ((window as any).universal_login_context) return
  const scripts = document.querySelectorAll('script:not([src])')
  for (const script of scripts) {
    const content = script.textContent ?? ''
    if (!content.includes('universal_login_context')) continue
    const match = content.match(/atob\(['"]([A-Za-z0-9+/=]+)['"]\)/)
    if (!match) continue
    try {
      const decoded = JSON.parse(
        new TextDecoder('utf-8').decode(
          Uint8Array.from(atob(match[1]), c => c.charCodeAt(0))
        )
      );
      (window as any).universal_login_context = decoded
    } catch (e) {
      console.error('[ACUL] Failed to decode universal_login_context', e)
    }
    break
  }
}

function mount() {
  extractContext()

  // Auth0's page template may not include a #root element.
  // Create one and append to body if it doesn't exist.
  let el = document.getElementById('root')
  if (!el) {
    el = document.createElement('div')
    el.id = 'root'
    document.body.appendChild(el)
  }

  createRoot(el).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
}

// Guard against the script running before the DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', mount)
} else {
  mount()
}
