import BruteForceUnblockSuccessManager from '@auth0/auth0-acul-js/brute-force-protection-unblock-success'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import './Screen.css'
import './BruteForceUnblockSuccess.css'

interface Props {
  isMobile?: boolean
}

export default function BruteForceUnblockSuccessScreen({ isMobile }: Props) {
  new BruteForceUnblockSuccessManager()

  function handleContinue() {
    const ctx = (window as any).universal_login_context
    const returnTo = ctx?.untrusted_data?.authorization_params?.redirect_uri
      ?? ctx?.client?.metadata?.app_url
      ?? window.location.origin
    window.location.href = returnTo
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <MobileScreenLayout
        title="Account Unlocked"
        content={
          <div className="bfus-mobile-content">
            <CheckCircle />
            <p className="bfus-description">
              Your account has been successfully unlocked. You can now sign in.
            </p>
            <button
              type="button"
              className="screen-btn-primary screen-btn-full bfus-mobile-btn"
              onClick={handleContinue}
            >
              Back to My Toyota
            </button>
          </div>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="bfus-page">
      <div className="bfus-card">
        <ToyotaLogo />
        <CheckCircle />
        <h1 className="bfus-title">Account<br />Unlocked</h1>
        <p className="bfus-description">
          Your account has been successfully unlocked. You can now sign in.
        </p>
        <button
          type="button"
          className="bfus-btn"
          onClick={handleContinue}
        >
          Back to My Toyota
        </button>
      </div>
    </div>
  )
}

function CheckCircle() {
  return (
    <div className="bfus-check-circle">
      <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8 18l7 7 13-13" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </div>
  )
}
