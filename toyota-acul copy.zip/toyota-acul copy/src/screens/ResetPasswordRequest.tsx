import { useState } from 'react'
import ResetPasswordRequest from '@auth0/auth0-acul-js/reset-password-request'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import FloatingInput from '../components/FloatingInput'
import LoadingOverlay from '../components/LoadingOverlay'
import steeringWheel from '../assets/steering-wheel.png'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './ResetPasswordRequest.css'

interface Props {
  isMobile?: boolean
}

export default function ResetPasswordRequestScreen({ isMobile }: Props) {
  const manager = new ResetPasswordRequest()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''
  const prefillEmail = manager.screen.data?.email ?? manager.screen.data?.username ?? ''

  const [email, setEmail] = useState(prefillEmail)
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email.trim()) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.resetPassword({ username: email.trim() })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          heroImage={steeringWheel}
          title="Let's Reset Your Password"
          content={
            <form onSubmit={handleSubmit} noValidate>
              <p className="rpr-mobile-subtitle">
                To reset your password, please enter the email associated with your account.
              </p>
              <FloatingInput
                id="email"
                label="Email address"
                type="email"
                value={email}
                onChange={setEmail}
                autoComplete="email"
                error={error}
                disabled={loading}
                variant="underline"
                required
              />
              <button
                type="submit"
                className="screen-btn-primary screen-btn-full rpr-mobile-btn"
                disabled={loading || !email.trim()}
              >
                {loading ? 'Sending…' : 'Email Me'}
              </button>
            </form>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="rpr-page">
        <div className="rpr-logo">
          <ToyotaLogo />
        </div>
        <div className="rpr-container">
          <h1 className="rpr-title">Let's Reset Your Password</h1>
          <p className="rpr-subtitle">
            To reset your password, please enter the email associated with your account.
          </p>
          <form onSubmit={handleSubmit} noValidate>
            <FloatingInput
              id="email"
              label="Email address"
              type="email"
              value={email}
              onChange={setEmail}
              autoComplete="email"
              error={error}
              disabled={loading}
              required
            />
            <div className="rpr-actions">
              <button
                type="submit"
                className="screen-btn-primary rpr-submit"
                disabled={loading || !email.trim()}
              >
                {loading ? 'Sending…' : 'Email Me'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
