import ResetPasswordErrorManager from '@auth0/auth0-acul-js/reset-password-error'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import './Screen.css'
import './ResetPasswordError.css'

interface Props {
  isMobile?: boolean
}

export default function ResetPasswordErrorScreen({ isMobile }: Props) {
  // SDK has no action methods — Back navigates to the login page
  new ResetPasswordErrorManager()

  function handleBack() {
    window.history.back()
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <MobileScreenLayout
        title="Password Reset Unsuccessful"
        content={
          <div>
            <p className="rpe-description">
              We are sorry, we were not able to reset your password. Please try again.
            </p>
            <button
              type="button"
              className="screen-btn-primary screen-btn-full rpe-mobile-back"
              onClick={handleBack}
            >
              Back
            </button>
          </div>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="rpe-page">
      <ToyotaLogo />
      <div className="rpe-container">
        <h1 className="rpe-title">Password Reset Unsuccessful</h1>
        <p className="rpe-description">
          We are sorry, we were not able to reset your password. Please try again.
        </p>
        <button
          type="button"
          className="screen-btn-primary rpe-back-btn"
          onClick={handleBack}
        >
          Back
        </button>
      </div>
    </div>
  )
}
