import { useState, useRef } from 'react'
import EmailIdentifierChallenge from '@auth0/auth0-acul-js/email-identifier-challenge'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import steeringWheel from '../assets/steering-wheel.png'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './EmailIdentifierChallenge.css'

function maskEmail(email: string): string {
  const [local, domain] = email.split('@')
  if (!domain) return email
  if (local.length <= 2) return `${local[0] ?? ''}***@${domain}`
  return `${local[0]}***@${domain}`
}

interface Props {
  isMobile?: boolean
}

export default function EmailIdentifierChallengeScreen({ isMobile }: Props) {
  const manager = new EmailIdentifierChallenge()
  const email = manager.screen.data?.email ?? ''
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  // Desktop: 6 individual boxes
  const [code, setCode] = useState(['', '', '', '', '', ''])
  // Mobile: single input
  const [mobileCode, setMobileCode] = useState('')

  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)
  const [resendLoading, setResendLoading] = useState(false)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  const codeString = code.join('')
  const isCodeComplete = codeString.length === 6
  const isMobileCodeComplete = mobileCode.length === 6

  function handleCodeChange(index: number, value: string) {
    const digit = value.replace(/\D/g, '').slice(-1)
    const newCode = [...code]
    newCode[index] = digit
    setCode(newCode)
    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  function handleKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  function handleMobileCodeChange(value: string) {
    // Only allow up to 6 digits
    setMobileCode(value.replace(/\D/g, '').slice(0, 6))
  }

  async function handleMobileSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isMobileCodeComplete) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.submitEmailChallenge({ code: mobileCode })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isCodeComplete) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.submitEmailChallenge({ code: codeString })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleResend() {
    setResendLoading(true)
    try {
      await manager.resendCode()
      setError('')
    } catch (err: any) {
      setError(err?.message ?? '')
    } finally {
      setResendLoading(false)
    }
  }

  async function handleBack() {
    try {
      await manager.returnToPrevious()
    } catch (err: any) {
      console.error('Failed to return to previous screen:', err)
    }
  }

  const otpInputs = (
    <div className="eic-otp-row">
      {code.map((digit, index) => (
        <input
          key={index}
          ref={(el) => { inputRefs.current[index] = el }}
          className="eic-otp-input"
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={digit}
          placeholder="–"
          onChange={(e) => handleCodeChange(index, e.target.value)}
          onKeyDown={(e) => handleKeyDown(index, e)}
          disabled={loading}
        />
      ))}
    </div>
  )

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <MobileScreenLayout
        heroImage={steeringWheel}
        title="We sent an email"
        content={
          <form onSubmit={handleMobileSubmit} noValidate>
            <p className="eic-description">
              Enter the code sent to <span className="eic-email">{maskEmail(email)}</span> to verify 
              you are the owner of this email address.
            </p>
            <p>
              In the future, we will use this method to authorize access to this application.
            </p>

            <input
              className="eic-single-input"
              type="text"
              inputMode="numeric"
              maxLength={6}
              value={mobileCode}
              placeholder="Enter 6-digit code"
              onChange={(e) => handleMobileCodeChange(e.target.value)}
              disabled={loading}
              autoComplete="one-time-code"
              style={{justifyContent: 'flex-start'}}
            />
            {error && <p className="eic-error">{error}</p>}


            <button
              type="submit"
              className="screen-btn-primary screen-btn-full eic-submit"
              disabled={loading || !isMobileCodeComplete}
              style={{width: '100%'}}
            >
              {loading ? 'Verifying…' : 'Verify Email Address'}
            </button>

            <p className="eic-no-access">Didn't receive a code?</p>
            <button
              type="button"
              className="eic-alt-link"
              onClick={handleResend}
              disabled={loading}
            >
              {resendLoading ? 'Sending…' : 'Request New Code'}
            </button>
          </form>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="eic-page">
      <div className="eic-container">
        <ToyotaLogo />

        <p className="eic-eyebrow">VERIFICATION</p>
        <h1 className="eic-title">Verification Required</h1>
        <p className="eic-description">
          To verify your account, we need to confirm the email address on the account.
        </p>
        {email && <p className="eic-email">{email}</p>}

        <form onSubmit={handleSubmit} noValidate>
          {otpInputs}
          {error && <p className="eic-error">{error}</p>}

          <button
            type="button"
            className="eic-resend"
            onClick={handleResend}
            disabled={resendLoading || loading}
          >
            {resendLoading ? 'Sending…' : 'Request New Code'}
          </button>

          <button
            type="submit"
            className="screen-btn-primary eic-submit"
            disabled={loading || !isCodeComplete}
          >
            {loading ? 'Verifying…' : 'Verify'}
          </button>
        </form>

        <p className="eic-trouble">No longer have access to this email?</p>
        <div className="eic-footer">
          <button
            type="button"
            className="eic-footer-link"
            onClick={handleBack}
            disabled={loading}
          >
            Try a Different Method &rsaquo;
          </button>
          <a href="https://www.toyota.com/support/contact-us" className="eic-footer-link">
            Support &rsaquo;
          </a>
        </div>
      </div>
    </div>
  )
}
