import { useState, useRef } from 'react'
import MfaEmailChallengeManager from '@auth0/auth0-acul-js/mfa-email-challenge'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import LoadingOverlay from '../components/LoadingOverlay'
import steeringWheel from '../assets/steering-wheel.png'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './EmailIdentifierChallenge.css'

function maskEmail(email: string): string {
  const [local, domain] = email.split('@')
  if (!domain) return email
  if (local.length <= 2) return `${local[0] ?? ''}***@${domain}`
  return `${local[0]}***@${domain}`
}

interface Props {
  isMobile?: boolean
}

export default function MfaEmailChallengeScreen({ isMobile }: Props) {
  const manager = new MfaEmailChallengeManager()
  const email = manager.screen.data?.email ?? ''
  const showRememberDevice = manager.screen.data?.showRememberDevice ?? false
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const [code, setCode] = useState(['', '', '', '', '', ''])
  const [mobileCode, setMobileCode] = useState('')
  const [rememberDevice, setRememberDevice] = useState(false)
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)
  const [resendLoading, setResendLoading] = useState(false)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  const codeString = code.join('')
  const isCodeComplete = codeString.length === 6
  const isMobileCodeComplete = mobileCode.length === 6

  function handleCodeChange(index: number, value: string) {
    const digit = value.replace(/\D/g, '').slice(-1)
    const newCode = [...code]
    newCode[index] = digit
    setCode(newCode)
    if (digit && index < 5) inputRefs.current[index + 1]?.focus()
  }

  function handleKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !code[index] && index > 0) inputRefs.current[index - 1]?.focus()
  }

  function handleMobileCodeChange(value: string) {
    setMobileCode(value.replace(/\D/g, '').slice(0, 6))
  }

  async function handleMobileSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isMobileCodeComplete) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.continue({ code: mobileCode, rememberDevice })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isCodeComplete) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.continue({ code: codeString, rememberDevice })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleResend() {
    setResendLoading(true)
    try {
      await manager.resendCode()
      setError('')
    } catch (err: any) {
      setError(err?.message ?? '')
    } finally {
      setResendLoading(false)
    }
  }

  async function handleTryAnotherMethod() {
    setLoading(true)
    try {
      await manager.tryAnotherMethod()
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  const otpInputs = (
    <div className="eic-otp-row">
      {code.map((digit, index) => (
        <input
          key={index}
          ref={(el) => { inputRefs.current[index] = el }}
          className="eic-otp-input"
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={digit}
          placeholder="–"
          onChange={(e) => handleCodeChange(index, e.target.value)}
          onKeyDown={(e) => handleKeyDown(index, e)}
          disabled={loading}
        />
      ))}
    </div>
  )

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          heroImage={steeringWheel}
          title="We sent an email"
          content={
            <form onSubmit={handleMobileSubmit} noValidate>
              <p className="eic-description">
                Enter the code sent to <span className="eic-email">{maskEmail(email)}</span> to verify
                you are the owner of this email address.
              </p>

              <input
                className="eic-single-input"
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={mobileCode}
                placeholder="Enter 6-digit code"
                onChange={(e) => handleMobileCodeChange(e.target.value)}
                disabled={loading}
                autoComplete="one-time-code"
              />
              {error && <p className="eic-error">{error}</p>}

              {showRememberDevice && (
                <label className="mfa-remember" style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14, margin: '8px 0 16px', cursor: 'pointer' }}>
                  <input type="checkbox" checked={rememberDevice} onChange={e => setRememberDevice(e.target.checked)} disabled={loading} style={{ width: 18, height: 18, accentColor: '#1a1a1a' }} />
                  Remember this device for 30 days
                </label>
              )}

              <button
                type="submit"
                className="screen-btn-primary screen-btn-full eic-submit"
                disabled={loading || !isMobileCodeComplete}
              >
                {loading ? 'Verifying…' : 'Verify Email'}
              </button>

              <p className="eic-no-access">Didn't receive a code?</p>
              <button type="button" className="eic-alt-link" onClick={handleResend} disabled={resendLoading || loading}>
                {resendLoading ? 'Sending…' : 'Request New Code'}
              </button>
            </form>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="eic-page">
        <div className="eic-container">
          <ToyotaLogo />

          <p className="eic-eyebrow">VERIFICATION</p>
          <h1 className="eic-title">Verify Your Identity</h1>
          <p className="eic-description">
            Enter the 6-digit code sent to your email address.
          </p>
          {email && <p className="eic-email">{email}</p>}

          <form onSubmit={handleSubmit} noValidate>
            {otpInputs}
            {error && <p className="eic-error">{error}</p>}

            <button type="button" className="eic-resend" onClick={handleResend} disabled={resendLoading || loading}>
              {resendLoading ? 'Sending…' : 'Request New Code'}
            </button>

            {showRememberDevice && (
              <label className="mfa-remember" style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14, margin: '-16px 0 24px', cursor: 'pointer' }}>
                <input type="checkbox" checked={rememberDevice} onChange={e => setRememberDevice(e.target.checked)} disabled={loading} style={{ width: 18, height: 18, accentColor: '#1a1a1a' }} />
                Remember this device for 30 days
              </label>
            )}

            <button type="submit" className="screen-btn-primary eic-submit" disabled={loading || !isCodeComplete}>
              {loading ? 'Verifying…' : 'Verify'}
            </button>
          </form>

          <p className="eic-trouble">Still having trouble?</p>
          <div className="eic-footer">
            <button type="button" className="eic-footer-link" onClick={handleTryAnotherMethod} disabled={loading}>
              Try Another Method &rsaquo;
            </button>
            <a href="https://www.toyota.com/support/contact-us" className="eic-footer-link">
              Support &rsaquo;
            </a>
          </div>
        </div>
      </div>
    </>
  )
}
