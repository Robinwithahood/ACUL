import { useState } from 'react'
import LoginPassword from '@auth0/auth0-acul-js/login-password'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import FloatingInput from '../components/FloatingInput'
import LoadingOverlay from '../components/LoadingOverlay'
import steeringWheel from '../assets/steering-wheel.png'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './LoginPassword.css'

interface Props {
  isMobile?: boolean
}

export default function LoginPasswordScreen({ isMobile }: Props) {
  const manager = new LoginPassword()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const prefillUsername = manager.screen.data?.username ?? ''
  const isPhone = !prefillUsername.includes('@') && prefillUsername.length > 0
  const usernameLabel = isPhone ? 'Phone Number' : 'Email'

  const [password, setPassword] = useState('')
  const [keepSignedIn, setKeepSignedIn] = useState(false)
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    if (!password) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.login({ username: prefillUsername, password })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  function handleTryDifferentSignIn() {
    const link = manager.screen.editIdentifierLink
    if (link) {
      window.location.href = link
    } else {
      window.history.back()
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          title="Sign In"
          heroImage={steeringWheel}
          content={
            <div>
              {prefillUsername && (
                <FloatingInput id="lp-email" label={usernameLabel} value={prefillUsername} onChange={() => {}} disabled variant="underline" />
              )}
              <form onSubmit={handleLogin} noValidate>
                <FloatingInput
                  id="password"
                  label="Password"
                  type="password"
                  value={password}
                  onChange={setPassword}
                  autoComplete="current-password"
                  error={error}
                  disabled={loading}
                  variant="underline"
                  required
                />

                <label className="lp-mobile-keep">
                  <input
                    type="checkbox"
                    checked={keepSignedIn}
                    onChange={e => setKeepSignedIn(e.target.checked)}
                    disabled={loading}
                  />
                  Keep me signed in
                </label>

                <button
                  type="submit"
                  className="screen-btn-primary screen-btn-full lp-mobile-submit"
                  disabled={loading || !password}
                >
                  Sign In
                </button>
              </form>

              <p className="lp-mobile-reset">
                Don't remember your password?{' '}
                <a href={manager.screen.resetPasswordLink ?? '#'} className="lp-mobile-reset-link">Reset it</a>
              </p>


            </div>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="lp-page">
        <div className="lp-container">
          <ToyotaLogo />
          <h1 className="lp-title">Sign In</h1>

          {prefillUsername && (
            <FloatingInput id="lp-email" label={usernameLabel} value={prefillUsername} onChange={() => {}} disabled />
          )}

          <form onSubmit={handleLogin} noValidate>
            <FloatingInput
              id="password"
              label="Password"
              type="password"
              value={password}
              onChange={setPassword}
              autoComplete="current-password"
              error={error}
              disabled={loading}
              required
            />
            <div className="lp-forgot">
              <a href={manager.screen.resetPasswordLink ?? '#'} className="lp-forgot-link">
                Forgot Password
              </a>
            </div>
            <p className="lp-required"><span className="lp-required-star">*</span>Required</p>
            <button
              type="submit"
              className="screen-btn-primary lp-submit"
              disabled={loading || !password}
            >
              Sign In
            </button>
          </form>

          <p className="lp-trouble">Still having trouble?</p>
          <div className="lp-footer">
            <button type="button" className="lp-footer-link" onClick={handleTryDifferentSignIn}>
              Try a Different Sign In &rsaquo;
            </button>
            <a href="https://www.toyota.com/support/contact-us" className="lp-footer-link">
              Support &rsaquo;
            </a>
          </div>
        </div>
      </div>
    </>
  )
}
