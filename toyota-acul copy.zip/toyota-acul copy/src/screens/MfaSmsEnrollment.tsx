import { useState } from 'react'
import MfaSmsEnrollmentManager from '@auth0/auth0-acul-js/mfa-sms-enrollment'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import FloatingInput from '../components/FloatingInput'
import LoadingOverlay from '../components/LoadingOverlay'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './MfaSmsEnrollment.css'

interface Props {
  isMobile?: boolean
}

export default function MfaSmsEnrollmentScreen({ isMobile }: Props) {
  const manager = new MfaSmsEnrollmentManager()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const [phone, setPhone] = useState('')
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const trimmed = phone.trim()
    if (!trimmed) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.continueEnrollment({ phone: trimmed })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleTryAnotherMethod() {
    setLoading(true)
    try {
      await manager.tryAnotherMethod()
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          title="Set Up SMS Verification"
          content={
            <div>
              <p className="mfa-enroll-description">
                Add your phone number to receive verification codes via text message.
              </p>

              <form onSubmit={handleSubmit} noValidate>
                <FloatingInput
                  id="mfa-phone"
                  label="Mobile Phone Number"
                  type="tel"
                  value={phone}
                  onChange={setPhone}
                  autoComplete="tel"
                  error={error}
                  disabled={loading}
                  variant="underline"
                  required
                />

                <button
                  type="submit"
                  className="screen-btn-primary screen-btn-full mfa-enroll-submit"
                  disabled={loading || !phone.trim()}
                >
                  {loading ? 'Please wait…' : 'Send Code'}
                </button>
              </form>

              <p className="mfa-enroll-trouble">Still having trouble?</p>
              <div className="mfa-enroll-footer-links">
                <button type="button" className="mfa-enroll-footer-link" onClick={handleTryAnotherMethod} disabled={loading}>
                  Try Another Method &rsaquo;
                </button>
              </div>
            </div>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="mfa-enroll-page">
        <div className="mfa-enroll-container">
          <ToyotaLogo />

          <p className="mfa-enroll-eyebrow">MULTI-FACTOR AUTHENTICATION</p>
          <h1 className="mfa-enroll-title">Set Up SMS Verification</h1>
          <p className="mfa-enroll-description">
            Add your phone number to receive verification codes via text message.
          </p>

          <form onSubmit={handleSubmit} noValidate>
            <FloatingInput
              id="mfa-phone"
              label="Mobile Phone Number"
              type="tel"
              value={phone}
              onChange={setPhone}
              autoComplete="tel"
              error={error}
              disabled={loading}
              required
            />

            <p className="mfa-enroll-hint">
              Standard message and data rates may apply.
            </p>

            <p className="mfa-enroll-required">
              <span className="mfa-enroll-required-star">*</span>Required
            </p>

            <button
              type="submit"
              className="screen-btn-primary mfa-enroll-submit"
              disabled={loading || !phone.trim()}
            >
              {loading ? 'Please wait…' : 'Send Code'}
            </button>
          </form>

          <p className="mfa-enroll-trouble">Still having trouble?</p>
          <div className="mfa-enroll-footer">
            <button type="button" className="mfa-enroll-footer-link" onClick={handleTryAnotherMethod} disabled={loading}>
              Try Another Method &rsaquo;
            </button>
            <a href="https://www.toyota.com/support/contact-us" className="mfa-enroll-footer-link">
              Support &rsaquo;
            </a>
          </div>
        </div>
      </div>
    </>
  )
}
