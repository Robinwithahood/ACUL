import { useState } from 'react'
import ResetPassword from '@auth0/auth0-acul-js/reset-password'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './ResetPasswordNew.css'

const PW_RULES = [
  { key: 'length',    label: 'Use 8 – 16 characters' },
  { key: 'upper',     label: 'Use uppercase and lowercase letters' },
  { key: 'number',    label: 'Use a number (0–9)' },
  { key: 'special',   label: 'Use a special character (@ # & % ! ~)' },
  { key: 'match',     label: 'Passwords match' },
]

function validate(pw: string, confirm: string) {
  return {
    length:  pw.length >= 8 && pw.length <= 16,
    upper:   /[A-Z]/.test(pw) && /[a-z]/.test(pw),
    number:  /[0-9]/.test(pw),
    special: /[@#&%!~]/.test(pw),
    match:   pw.length > 0 && pw === confirm,
  }
}

interface Props {
  isMobile?: boolean
}

export default function ResetPasswordNewScreen({ isMobile }: Props) {
  const manager = new ResetPassword()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const [password, setPassword]   = useState('')
  const [confirm, setConfirm]     = useState('')
  const [showPw, setShowPw]       = useState(false)
  const [showCf, setShowCf]       = useState(false)
  const [error, setError]         = useState(serverError)
  const [loading, setLoading]     = useState(false)

  const rules = validate(password, confirm)
  const allPass = Object.values(rules).every(Boolean)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!allPass) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.resetPassword({ 'password-reset': password, 're-enter-password': confirm } as any)
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <MobileScreenLayout
        title="Reset Your Password"
        content={
          <form onSubmit={handleSubmit} noValidate>
            <div className="rpn-field-wrap">
              <input
                className="rpn-input rpn-input--underline"
                type={showPw ? 'text' : 'password'}
                placeholder="Password *"
                value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="new-password"
                disabled={loading}
              />
              <button type="button" className="rpn-show-btn" onClick={() => setShowPw(p => !p)} tabIndex={-1}>
                <EyeIcon /> {showPw ? 'Hide' : 'Show'}
              </button>
            </div>

            <div className="rpn-field-wrap rpn-field-wrap--underline">
              <input
                className="rpn-input rpn-input--underline"
                type={showCf ? 'text' : 'password'}
                placeholder="Confirm Password *"
                value={confirm}
                onChange={e => setConfirm(e.target.value)}
                autoComplete="new-password"
                disabled={loading}
              />
              <button type="button" className="rpn-show-btn" onClick={() => setShowCf(p => !p)} tabIndex={-1}>
                <EyeIcon /> {showCf ? 'Hide' : 'Show'}
              </button>
            </div>

            <ul className="rpn-rules rpn-rules--mobile">
              {PW_RULES.map(r => (
                <li key={r.key} className={`rpn-rule ${rules[r.key as keyof typeof rules] ? 'rpn-rule--pass' : ''}`}>
                  <RuleIcon checked={rules[r.key as keyof typeof rules]} />
                  {r.label}
                </li>
              ))}
            </ul>

            {error && <p className="rpn-error">{error}</p>}

            <button
              type="submit"
              className="screen-btn-primary screen-btn-full rpn-mobile-submit"
              disabled={loading || !allPass}
            >
              {loading ? 'Resetting…' : 'Reset Password'}
            </button>
          </form>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="rpn-page">
      <ToyotaLogo />
      <h1 className="rpn-title">Reset Your Password</h1>

      <div className="rpn-card">
        <div className="rpn-left">
          <div className="rpn-field-wrap">
            <input
              className="rpn-input"
              type={showPw ? 'text' : 'password'}
              placeholder="Password *"
              value={password}
              onChange={e => setPassword(e.target.value)}
              autoComplete="new-password"
              disabled={loading}
            />
            <button type="button" className="rpn-show-btn" onClick={() => setShowPw(p => !p)} tabIndex={-1}>
              <EyeIcon /> {showPw ? 'Hide' : 'Show'}
            </button>
          </div>

          <div className="rpn-field-wrap">
            <input
              className="rpn-input"
              type={showCf ? 'text' : 'password'}
              placeholder="Confirm Password *"
              value={confirm}
              onChange={e => setConfirm(e.target.value)}
              autoComplete="new-password"
              disabled={loading}
            />
            <button type="button" className="rpn-show-btn" onClick={() => setShowCf(p => !p)} tabIndex={-1}>
              <EyeIcon /> {showCf ? 'Hide' : 'Show'}
            </button>
          </div>

          {error && <p className="rpn-error">{error}</p>}
          <p className="rpn-required"><span className="rpn-required-star">*</span> Required fields</p>
        </div>

        <div className="rpn-divider" />

        <div className="rpn-right">
          <p className="rpn-rules-heading">Your new password must meet the following requirements:</p>
          <ul className="rpn-rules">
            {PW_RULES.map(r => (
              <li key={r.key} className={`rpn-rule ${rules[r.key as keyof typeof rules] ? 'rpn-rule--pass' : ''}`}>
                <RuleIcon checked={rules[r.key as keyof typeof rules]} />
                {r.label}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <form onSubmit={handleSubmit} noValidate>
        <div className="rpn-actions">
          <button
            type="submit"
            className="screen-btn-primary rpn-submit"
            disabled={loading || !allPass}
          >
            {loading ? 'Resetting…' : 'Reset Password'}
          </button>
        </div>
      </form>

      <div className="rpn-footer">
        <a href="https://www.toyota.com/support/contact-us" className="rpn-contact">Contact Us</a>
      </div>
    </div>
  )
}

function EyeIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M1 12C1 12 5 4 12 4s11 8 11 8-4 8-11 8S1 12 1 12z" stroke="#555" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="12" cy="12" r="3" stroke="#555" strokeWidth="1.8"/>
    </svg>
  )
}

function RuleIcon({ checked }: { checked: boolean }) {
  return checked ? (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="rpn-rule-icon">
      <circle cx="10" cy="10" r="9" stroke="#aaa" strokeWidth="1.5" fill="#e8e8e8"/>
      <path d="M6 10l3 3 5-5" stroke="#555" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ) : (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="rpn-rule-icon">
      <circle cx="10" cy="10" r="9" stroke="#ccc" strokeWidth="1.5"/>
    </svg>
  )
}
