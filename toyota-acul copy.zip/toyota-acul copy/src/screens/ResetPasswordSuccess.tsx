import ResetPasswordSuccessManager from '@auth0/auth0-acul-js/reset-password-success'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import './Screen.css'
import './ResetPasswordSuccess.css'

interface Props {
  isMobile?: boolean
}

export default function ResetPasswordSuccessScreen({ isMobile }: Props) {
  new ResetPasswordSuccessManager()

  function handleBack() {
    // Try to get a returnTo from the Auth0 context, fall back to origin
    const ctx = (window as any).universal_login_context
    const returnTo = ctx?.untrusted_data?.authorization_params?.redirect_uri
      ?? ctx?.client?.metadata?.app_url
      ?? window.location.origin
    window.location.href = returnTo
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <MobileScreenLayout
        title="Password Reset Successful"
        content={
          <div className="rps-mobile-content">
            <CheckCircle />
            <p className="rps-description">Your password has been changed successfully.</p>
            <button
              type="button"
              className="screen-btn-primary screen-btn-full rps-mobile-btn"
              onClick={handleBack}
            >
              Back to My Toyota
            </button>
          </div>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="rps-page">
      <div className="rps-card">
        <ToyotaLogo />
        <CheckCircle />
        <h1 className="rps-title">Password Reset<br />Successful</h1>
        <p className="rps-description">Your password has been changed successfully.</p>
        <button
          type="button"
          className="rps-back-btn"
          onClick={handleBack}
        >
          Back to My Toyota
        </button>
      </div>
    </div>
  )
}

function CheckCircle() {
  return (
    <div className="rps-check-circle">
      <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8 18l7 7 13-13" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </div>
  )
}
