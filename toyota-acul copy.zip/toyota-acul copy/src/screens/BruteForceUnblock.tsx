import { useState } from 'react'
import BruteForceUnblock from '@auth0/auth0-acul-js/brute-force-protection-unblock'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import LoadingOverlay from '../components/LoadingOverlay'
import './Screen.css'
import './BruteForceUnblock.css'

interface Props {
  isMobile?: boolean
}

export default function BruteForceUnblockScreen({ isMobile }: Props) {
  const manager = new BruteForceUnblock()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(serverError)

  async function handleUnblock() {
    setLoading(true)
    setError('')
    try {
      await manager.unblockAccount({})
    } catch (err: any) {
      setError(err?.message ?? 'Something went wrong. Please try again.')
      setLoading(false)
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          title="Account Locked"
          content={
            <div className="bfu-mobile-content">
              <LockIcon />
              <p className="bfu-description">
                Your account has been locked due to too many failed login attempts.
                Click the button below to unlock your account.
              </p>
              {error && <p className="bfu-error">{error}</p>}
              <button
                type="button"
                className="screen-btn-primary screen-btn-full bfu-mobile-btn"
                onClick={handleUnlock}
                disabled={loading}
              >
                {loading ? 'Please wait…' : 'Unlock My Account'}
              </button>
            </div>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="bfu-page">
        <div className="bfu-card">
          <ToyotaLogo />
          <LockIcon />
          <h1 className="bfu-title">Account Locked</h1>
          <p className="bfu-description">
            Your account has been locked due to too many failed login attempts.
            Click the button below to unlock your account.
          </p>
          {error && <p className="bfu-error">{error}</p>}
          <button
            type="button"
            className="bfu-btn"
            onClick={handleUnblock}
            disabled={loading}
          >
            {loading ? 'Please wait…' : 'Unlock My Account'}
          </button>
        </div>
      </div>
    </>
  )

  function handleUnlock() {
    handleUnblock()
  }
}

function LockIcon() {
  return (
    <div className="bfu-lock-circle">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="5" y="11" width="14" height="10" rx="2" stroke="#ffffff" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M8 11V7a4 4 0 0 1 8 0v4" stroke="#ffffff" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="12" cy="16" r="1.5" fill="#ffffff"/>
      </svg>
    </div>
  )
}
