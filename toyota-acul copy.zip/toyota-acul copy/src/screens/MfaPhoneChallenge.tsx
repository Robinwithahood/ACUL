import { useState } from 'react'
import MfaPhoneChallengeManager from '@auth0/auth0-acul-js/mfa-phone-challenge'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import LoadingOverlay from '../components/LoadingOverlay'
import './Screen.css'
import './MfaPhoneChallenge.css'

interface Props {
  isMobile?: boolean
}

export default function MfaPhoneChallengeScreen({ isMobile }: Props) {
  const manager = new MfaPhoneChallengeManager()
  const phoneNumber = manager.screen.data?.phoneNumber ?? ''
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)

  const displayPhone = phoneNumber.replace(/^\+\d{1,3}/, '')

  async function handleContinue(type: 'sms' | 'voice') {
    setError('')
    setLoading(true)
    try {
      await manager.continue({ type })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleTryAnotherMethod() {
    setLoading(true)
    try {
      await manager.tryAnotherMethod()
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  const content = (
    <div className="mpc-content">
      <p className="mpc-description">
        How would you like to receive your verification code?
      </p>
      {phoneNumber && <p className="mpc-phone">{displayPhone}</p>}
      {error && <p className="mpc-error">{error}</p>}

      <button
        type="button"
        className="mpc-option-btn"
        onClick={() => handleContinue('sms')}
        disabled={loading}
      >
        <SmsIcon />
        <span>
          <strong>Text me a code</strong>
          <span className="mpc-option-sub">Receive a code via SMS</span>
        </span>
      </button>

      <button
        type="button"
        className="mpc-option-btn"
        onClick={() => handleContinue('voice')}
        disabled={loading}
      >
        <PhoneIcon />
        <span>
          <strong>Call me</strong>
          <span className="mpc-option-sub">Receive a code via voice call</span>
        </span>
      </button>
    </div>
  )

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          title="Verify Your Identity"
          content={
            <div>
              {content}
              <div className="mpc-footer-links">
                <button type="button" className="mpc-footer-link" onClick={handleTryAnotherMethod} disabled={loading}>
                  Try Another Method &rsaquo;
                </button>
              </div>
            </div>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="mpc-page">
        <div className="mpc-container">
          <ToyotaLogo />
          <p className="mpc-eyebrow">VERIFICATION</p>
          <h1 className="mpc-title">Verify Your Identity</h1>

          {content}

          <p className="mpc-trouble">Still having trouble?</p>
          <div className="mpc-footer">
            <button type="button" className="mpc-footer-link" onClick={handleTryAnotherMethod} disabled={loading}>
              Try Another Method &rsaquo;
            </button>
            <a href="https://www.toyota.com/support/contact-us" className="mpc-footer-link">
              Support &rsaquo;
            </a>
          </div>
        </div>
      </div>
    </>
  )
}

function SmsIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
}

function PhoneIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.27h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.91a16 16 0 0 0 6 6l.91-.91a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
}
