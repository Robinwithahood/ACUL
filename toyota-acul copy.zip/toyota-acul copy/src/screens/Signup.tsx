import { useState } from 'react'
import Signup from '@auth0/auth0-acul-js/signup'
import ScreenLayout from '../components/ScreenLayout'
import FloatingInput from '../components/FloatingInput'
import SSOButtons from '../components/SSOButtons'
import './Screen.css'

export default function SignupScreen() {
  const manager = new Signup()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const [email, setEmail] = useState('')
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault()
    if (!email.trim()) { setError('Email is required.'); return }

    setError('')
    setLoading(true)
    try {
      await manager.signup({ email })
    } catch (err: any) {
      setError(err?.message ?? 'Registration failed. Please try again.')
      setLoading(false)
    }
  }

  async function handleFederated(connection: string) {
    setLoading(true)
    try {
      await manager.federatedSignup({ connection })
    } catch {
      setLoading(false)
    }
  }

  const leftPanel = (
    <div>
      <p className="screen-subtitle">Create your Toyota account</p>
      <form onSubmit={handleSignup} noValidate>
        <FloatingInput
          id="email"
          label="Email address"
          type="email"
          value={email}
          onChange={setEmail}
          autoComplete="email"
          error={error}
          disabled={loading}
        />

        <div className="screen-actions">
          <button
            type="button"
            className="screen-btn-outline"
            disabled={loading}
            onClick={() => manager.federatedSignup({ connection: 'login' })}
          >
            Sign In
          </button>
          <button
            type="submit"
            className="screen-btn-primary"
            disabled={loading || !email.trim()}
          >
            {loading ? 'Please wait…' : 'Continue'}
          </button>
        </div>
      </form>

      <p className="screen-hint">
        You can use your My Lexus or My Toyota or SmartPath account information to sign up.
      </p>
    </div>
  )

  const rightPanel = (
    <SSOButtons
      onApple={() => handleFederated('apple')}
      onGoogle={() => handleFederated('google-oauth2')}
      onFacebook={() => handleFederated('facebook')}
      disabled={loading}
    />
  )

  return (
    <ScreenLayout
      title="Create Account"
      left={leftPanel}
      right={rightPanel}
    />
  )
}
