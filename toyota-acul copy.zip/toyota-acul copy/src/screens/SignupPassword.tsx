import { useState } from 'react'
import SignupPassword from '@auth0/auth0-acul-js/signup-password'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import FloatingInput from '../components/FloatingInput'
import steeringWheel from '../assets/steering-wheel.png'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './SignupPassword.css'

const PW_RULES = [
  { key: 'uppercase', label: 'One uppercase letter' },
  { key: 'lowercase', label: 'One lowercase letter' },
  { key: 'number',    label: 'One number' },
  { key: 'special',   label: 'One special character' },
  { key: 'length',    label: '8-20 characters in total' },
]

const DESKTOP_PW_RULES = [
  { key: 'length',    label: 'Use 8-20 Characters' },
  { key: 'uppercase', label: 'Use uppercase and lowercase letters' },
  { key: 'number',    label: 'Use a number (0-9)' },
  { key: 'special',   label: 'Use a special character (@ # & % ! ~)' },
]

function validatePassword(pw: string) {
  return {
    length:    pw.length >= 8 && pw.length <= 20,
    uppercase: /[A-Z]/.test(pw),
    lowercase: /[a-z]/.test(pw),
    number:    /[0-9]/.test(pw),
    special:   /[@#&%!~]/.test(pw),
  }
}

interface Props {
  isMobile?: boolean
}

export default function SignupPasswordScreen({ isMobile }: Props) {
  const manager = new SignupPassword()
  const prefillEmail = manager.screen.data?.email ?? ''

  // Try to get given_name/family_name from Auth0's transaction context first (Option A),
  // then fall back to sessionStorage (set by signup-id as a safety net).
  const screenData = (window as any).universal_login_context?.screen?.data ?? {}
  const storedMeta = (() => {
    try { return JSON.parse(sessionStorage.getItem('toyota_signup_meta') ?? '{}') } catch { return {} }
  })()
  const prefillFirstName: string = screenData.given_name ?? storedMeta.given_name ?? ''
  const prefillLastName: string  = screenData.family_name ?? storedMeta.family_name ?? ''

  const [password, setPassword]       = useState('')
  const [confirmPassword, setConfirm] = useState('')
  const [firstName, setFirstName]     = useState(prefillFirstName)
  const [lastName, setLastName]       = useState(prefillLastName)
  const phone = manager.screen.data?.phoneNumber ?? ''
  const serverErrors = manager.getErrors()
  const initialError = serverErrors[0]?.message?.toLowerCase().includes('email')
    ? '' : (serverErrors[0]?.message ?? '')
  const [error, setError]   = useState(initialError)
  const [loading, setLoading] = useState(false)

  const rules = validatePassword(password)
  const allRulesPass = Object.values(rules).every(Boolean)

  // Desktop also uses confirm password
  const pwMatch  = password.length > 0 && password === confirmPassword
  const desktopValid = allRulesPass && pwMatch

  async function handleMobileSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!allRulesPass) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.signup({
        email: prefillEmail,
        phone_number: phone || undefined,
        password,
        given_name: firstName.trim(),
        family_name: lastName.trim(),
      } as any)
      sessionStorage.removeItem('toyota_signup_meta')
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleDesktopSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!desktopValid) { setError(CLIENT_ERR); return }
    if (!firstName.trim()) { setError(CLIENT_ERR); return }
    if (!lastName.trim()) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.signup({
        email: prefillEmail,
        phone_number: manager.screen.data?.phoneNumber,
        password,
      })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    const canSubmit = !loading && allRulesPass
    return (
      <MobileScreenLayout
        heroImage={steeringWheel}
        title="Create an account"
        content={
          <form onSubmit={handleMobileSubmit} noValidate>

            <FloatingInput
              id="password"
              label="Password"
              type="password"
              value={password}
              onChange={setPassword}
              autoComplete="new-password"
              error={error}
              disabled={loading}
              variant="underline"
            />

            <p className="spm-rules-heading">Password must contain:</p>
            <ul className="spm-rules">
              {PW_RULES.map(r => {
                const pass = rules[r.key as keyof typeof rules]
                return (
                  <li key={r.key} className={`spm-rule ${pass ? 'spm-rule--pass' : ''}`}>
                    <CheckIcon checked={pass} />
                    {r.label}
                  </li>
                )
              })}
            </ul>

            <p className="spm-legal">
              By registering, you confirm that you are the owner or primary user of this mobile number. You agree to receive automated text messages to confirm your mobile number. Message and data rates may apply.
            </p>
            <p className="spm-legal">
              By Registering, you agree to{' '}
              <a href="#terms" className="spm-legal-link">Toyota's Legal Terms</a>,{' '}
              <a href="#privacy" className="spm-legal-link">Privacy Policy</a> and{' '}
              <a href="#eula" className="spm-legal-link">End User License Agreement</a>.
            </p>

            <button
              type="submit"
              className="screen-btn-primary screen-btn-full spm-register-btn"
              disabled={!canSubmit}
            >
              {loading ? 'Creating…' : 'Register'}
            </button>

            <p className="spm-signin">
              Already have an account?{' '}
              <a href="#signin" className="spm-signin-link">Sign in</a>
            </p>
          </form>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="sp-page">
      <div className="sp-container">
        <ToyotaLogo />
        <h1 className="sp-title">Create Account</h1>
        <p className="sp-description">Create a free account with My Toyota to receive offers from your preferred dealer, stay connected to your vehicle, and access all the tools for your Toyota in one place.</p>

        <div className="sp-card">
          <FloatingInput id="email" label="Email" type="text" value={prefillEmail} onChange={() => {}} disabled />

          <div className="sp-row">
            <div style={{ flex: 1 }}>
              <FloatingInput id="password" label="Password" type="password" value={password} onChange={setPassword} autoComplete="new-password" disabled={loading} />
            </div>
            <div style={{ flex: 1 }}>
              <FloatingInput id="confirm-password" label="Confirm Password" type="password" value={confirmPassword} onChange={setConfirm} autoComplete="new-password" disabled={loading} />
            </div>
          </div>

          <p className="sp-rules-heading">Your password must meet the following requirements:</p>
          <ul className="sp-rules">
            {DESKTOP_PW_RULES.map(r => (
              <li key={r.key} className={`sp-rule ${rules[r.key as keyof typeof rules] ? 'sp-rule--pass' : 'sp-rule--pending'}`}>
                <span className="sp-rule-icon">{rules[r.key as keyof typeof rules] ? '✓' : '○'}</span>
                {r.label}
              </li>
            ))}
            <li className={`sp-rule ${pwMatch ? 'sp-rule--pass' : 'sp-rule--pending'}`}>
              <span className="sp-rule-icon">{pwMatch ? '✓' : '○'}</span>
              Passwords match
            </li>
          </ul>

          <hr className="sp-divider" />

          <div className="sp-row">
            <FloatingInput id="firstName" label="First Name" value={firstName} onChange={setFirstName} disabled={loading} />
            <FloatingInput id="lastName"  label="Last Name"  value={lastName}  onChange={setLastName}  disabled={loading} />
          </div>

          {error && <p className="sp-error">{error}</p>}
          <p className="sp-required-note"><span className="sp-required">*</span> Required Fields</p>
        </div>

        <div className="sp-actions">
          <button type="button" className="screen-btn-outline" onClick={() => window.history.back()} disabled={loading}>Cancel</button>
          <button type="submit" className="screen-btn-primary" disabled={loading || !desktopValid || !firstName.trim() || !lastName.trim()} onClick={handleDesktopSubmit}>
            {loading ? 'Creating…' : 'Create Account'}
          </button>
        </div>

        <p className="sp-signin-link">
          <a href="#signin" className="screen-link" style={{ color: '#EB0A1E', fontWeight: 500 }}>
            Already have an account? &rsaquo;
          </a>
        </p>
      </div>
    </div>
  )
}

function CheckIcon({ checked }: { checked: boolean }) {
  return (
    <span className="spm-rule-icon" aria-hidden="true">
      {checked ? (
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path d="M2 6l3 3 5-5" stroke="#2e7d32" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ) : (
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path d="M2 6l3 3 5-5" stroke="#bbb" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      )}
    </span>
  )
}
