import { useState, useEffect } from 'react'
import ResetPasswordEmail from '@auth0/auth0-acul-js/reset-password-email'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import LoadingOverlay from '../components/LoadingOverlay'
import steeringWheel from '../assets/steering-wheel.png'
import './Screen.css'
import './ResetPasswordEmail.css'

const RESEND_COOLDOWN = 60 // seconds

interface Props {
  isMobile?: boolean
}

export default function ResetPasswordEmailScreen({ isMobile }: Props) {
  const manager = new ResetPasswordEmail()
  const email = manager.screen.data?.username ?? ''

  const [loading, setLoading] = useState(false)
  const [cooldown, setCooldown] = useState(RESEND_COOLDOWN)

  // Countdown timer for resend
  useEffect(() => {
    if (cooldown <= 0) return
    const timer = setTimeout(() => setCooldown(c => c - 1), 1000)
    return () => clearTimeout(timer)
  }, [cooldown])

  async function handleResend() {
    if (cooldown > 0 || loading) return
    setLoading(true)
    try {
      await manager.resendEmail()
      setCooldown(RESEND_COOLDOWN)
    } catch {
      setLoading(false)
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          heroImage={steeringWheel}
          title="We sent an email"
          content={
            <div>
              <p className="rpe-mobile-desc">
                If an account exists with this email, you will receive a link to reset your password.
              </p>
              {email && <p className="rpe-mobile-email">{email}</p>}
              <div className="rpe-mobile-resend">
                <p className="rpe-mobile-resend-label">Didn't receive an email?</p>
                {cooldown > 0 ? (
                  <p className="rpe-mobile-cooldown">
                    New link available in <strong>{cooldown}</strong> seconds
                  </p>
                ) : (
                  <button
                    type="button"
                    className="rpe-mobile-resend-btn"
                    onClick={handleResend}
                    disabled={loading}
                  >
                    Resend email
                  </button>
                )}
              </div>
              <button
                type="button"
                className="rpe-mobile-alternate"
                onClick={handleResend}
                disabled={cooldown > 0 || loading}
              >
                Try an alternate address &rsaquo;
              </button>
            </div>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="rpe-page">
        <div className="rpe-logo">
          <ToyotaLogo />
        </div>
        <div className="rpe-container">
          <div className="rpe-icon">
            <EnvelopeIcon />
          </div>
          <h1 className="rpe-title">We Sent you an Email</h1>
          <p className="rpe-description">
            Check your email address{email && <> <strong>{email}</strong></>}. It contains a link
            to reset your password. This link will be active for 72 hours. Didn't receive the
            email? Check your spam folder in case the email was incorrectly identified.
          </p>
          <button
            type="button"
            className="rpe-alternate-link"
            onClick={handleResend}
            disabled={loading}
          >
            Try an Alternate Address? &rsaquo;
          </button>
          <div className="rpe-actions">
            <a
              href="https://www.toyota.com/support/contact-us"
              className="screen-btn-primary rpe-contact-btn"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </>
  )
}

function EnvelopeIcon() {
  return (
    <svg width="120" height="96" viewBox="0 0 120 96" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="8" width="112" height="80" rx="8" fill="#f0f0f0" stroke="#e0e0e0" strokeWidth="2"/>
      <path d="M4 20 L60 56 L116 20" stroke="#e0e0e0" strokeWidth="2" fill="none"/>
      <path d="M4 88 L44 52" stroke="#e0e0e0" strokeWidth="2"/>
      <path d="M116 88 L76 52" stroke="#e0e0e0" strokeWidth="2"/>
    </svg>
  )
}
