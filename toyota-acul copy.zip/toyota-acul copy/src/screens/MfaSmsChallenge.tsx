import { useState, useRef } from 'react'
import MfaSmsChallengeManager from '@auth0/auth0-acul-js/mfa-sms-challenge'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import LoadingOverlay from '../components/LoadingOverlay'
import { maskPhone } from '../utils/maskPhone'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './MfaSmsChallenge.css'

interface Props {
  isMobile?: boolean
}

export default function MfaSmsChallengeScreen({ isMobile }: Props) {
  const manager = new MfaSmsChallengeManager()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const phoneNumber = (manager.screen as any).data?.phoneNumber ?? ''
  const showRememberDevice = (manager.screen as any).data?.showRememberDevice ?? false
  const showLinkVoice = (manager.screen as any).data?.showLinkVoice ?? false

  const [code, setCode] = useState(['', '', '', '', '', ''])
  const [rememberDevice, setRememberDevice] = useState(false)
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)
  const [resendLoading, setResendLoading] = useState(false)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  const codeString = code.join('')
  const isCodeComplete = codeString.length === 6

  function handleCodeChange(index: number, value: string) {
    const digit = value.replace(/\D/g, '').slice(-1)
    const newCode = [...code]
    newCode[index] = digit
    setCode(newCode)
    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  function handleKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isCodeComplete) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.continueMfaSmsChallenge({ code: codeString, rememberDevice })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleResend() {
    setResendLoading(true)
    try {
      await manager.resendCode()
      setError('')
    } catch (err: any) {
      setError(err?.message ?? '')
    } finally {
      setResendLoading(false)
    }
  }

  async function handleGetACall() {
    setLoading(true)
    try {
      await manager.getACall()
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleTryAnotherMethod() {
    setLoading(true)
    try {
      await manager.tryAnotherMethod()
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  const otpInputs = (
    <div className="mfa-otp-row">
      {code.map((digit, index) => (
        <input
          key={index}
          ref={(el) => { inputRefs.current[index] = el }}
          className="mfa-otp-input"
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={digit}
          placeholder="–"
          onChange={(e) => handleCodeChange(index, e.target.value)}
          onKeyDown={(e) => handleKeyDown(index, e)}
          disabled={loading}
        />
      ))}
    </div>
  )

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout
          title="Verify Your Identity"
          content={
            <form onSubmit={handleSubmit} noValidate>
              <p className="mfa-description">
                We sent a 6-digit verification code to your phone number.
              </p>
              {phoneNumber && <p className="mfa-phone">{maskPhone(phoneNumber)}</p>}

              {otpInputs}
              {error && <p className="mfa-error">{error}</p>}

              <button
                type="button"
                className="mfa-resend"
                onClick={handleResend}
                disabled={resendLoading || loading}
              >
                {resendLoading ? 'Sending…' : 'Request New Code'}
              </button>

              {showRememberDevice && (
                <label className="mfa-remember">
                  <input
                    type="checkbox"
                    checked={rememberDevice}
                    onChange={e => setRememberDevice(e.target.checked)}
                    disabled={loading}
                  />
                  Remember this device for 30 days
                </label>
              )}

              <button
                type="submit"
                className="screen-btn-primary screen-btn-full mfa-submit"
                disabled={loading || !isCodeComplete}
              >
                {loading ? 'Verifying…' : 'Verify'}
              </button>

              <p className="mfa-trouble">Still having trouble?</p>
              <div className="mfa-footer-links">
                {showLinkVoice && (
                  <button type="button" className="mfa-footer-link" onClick={handleGetACall} disabled={loading}>
                    Get a Call Instead &rsaquo;
                  </button>
                )}
                <button type="button" className="mfa-footer-link" onClick={handleTryAnotherMethod} disabled={loading}>
                  Try Another Method &rsaquo;
                </button>
              </div>
            </form>
          }
        />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <>
      {loading && <LoadingOverlay />}
      <div className="mfa-page">
        <div className="mfa-container">
          <ToyotaLogo />

          <p className="mfa-eyebrow">VERIFICATION</p>
          <h1 className="mfa-title">Verify Your Identity</h1>
          <p className="mfa-description">
            We sent a 6-digit verification code to your phone number.
          </p>
          {phoneNumber && <p className="mfa-phone">{phoneNumber.replace(/^\+\d{1,3}/, '')}</p>}

          <form onSubmit={handleSubmit} noValidate>
            {otpInputs}
            {error && <p className="mfa-error">{error}</p>}

            <button
              type="button"
              className="mfa-resend"
              onClick={handleResend}
              disabled={resendLoading || loading}
            >
              {resendLoading ? 'Sending…' : 'Request New Code'}
            </button>

            {showRememberDevice && (
              <label className="mfa-remember">
                <input
                  type="checkbox"
                  checked={rememberDevice}
                  onChange={e => setRememberDevice(e.target.checked)}
                  disabled={loading}
                />
                Remember this device for 30 days
              </label>
            )}

            <button
              type="submit"
              className="screen-btn-primary mfa-submit"
              disabled={loading || !isCodeComplete}
            >
              {loading ? 'Verifying…' : 'Verify'}
            </button>
          </form>

          <p className="mfa-trouble">Still having trouble?</p>
          <div className="mfa-footer">
            {showLinkVoice && (
              <button type="button" className="mfa-footer-link" onClick={handleGetACall} disabled={loading}>
                Get a Call Instead &rsaquo;
              </button>
            )}
            <button type="button" className="mfa-footer-link" onClick={handleTryAnotherMethod} disabled={loading}>
              Try Another Method &rsaquo;
            </button>
            <a href="https://www.toyota.com/support/contact-us" className="mfa-footer-link">
              Support &rsaquo;
            </a>
          </div>
        </div>
      </div>
    </>
  )
}
