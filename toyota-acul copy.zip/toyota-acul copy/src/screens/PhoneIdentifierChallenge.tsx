import { useState, useRef } from 'react'
import PhoneIdentifierChallenge from '@auth0/auth0-acul-js/login-passwordless-sms-otp'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import { maskPhone } from '../utils/maskPhone'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './PhoneIdentifierChallenge.css'

interface Props {
  isMobile?: boolean
}

export default function PhoneIdentifierChallengeScreen({ isMobile }: Props) {
  const manager = new PhoneIdentifierChallenge()
  const phone = manager.screen.data?.phone_number ?? ''
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  // Desktop: 6 individual boxes
  const [code, setCode] = useState(['', '', '', '', '', ''])
  // Mobile: single input
  const [mobileCode, setMobileCode] = useState('')

  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)
  const [resendLoading, setResendLoading] = useState(false)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  const codeString = code.join('')
  const isCodeComplete = codeString.length === 6
  const isMobileCodeComplete = mobileCode.length === 6

  function handleCodeChange(index: number, value: string) {
    const digit = value.replace(/\D/g, '').slice(-1)
    const newCode = [...code]
    newCode[index] = digit
    setCode(newCode)
    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  function handleKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  function handleMobileCodeChange(value: string) {
    setMobileCode(value.replace(/\D/g, '').slice(0, 6))
  }

  async function handleMobileSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isMobileCodeComplete) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.submitOTP({ code: mobileCode })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isCodeComplete) { setError(CLIENT_ERR); return }
    setError('')
    setLoading(true)
    try {
      await manager.submitOTP({ code: codeString })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleResend() {
    setResendLoading(true)
    try {
      await manager.resendOTP()
      setError('')
    } catch (err: any) {
      setError(err?.message ?? '')
    } finally {
      setResendLoading(false)
    }
  }

  function getAuthorizeUrl(extraParams?: Record<string, string>) {
    const ctx = (window as any).universal_login_context
    const params = ctx?.transaction?.params ?? {}
    const searchParams = new URLSearchParams({ ...params, ...extraParams })
    return `${window.location.origin}/authorize?${searchParams}`
  }

  function handleSignInWithPassword() {
    window.location.href = getAuthorizeUrl({
      login_hint: phone,
      prompt: 'login',
      connection: 'Username-Password-Authentication',
    })
  }

  function handleTryDifferentSignIn() {
    window.location.href = getAuthorizeUrl()
  }

  const otpInputs = (
    <div className="pic-otp-row">
      {code.map((digit, index) => (
        <input
          key={index}
          ref={(el) => { inputRefs.current[index] = el }}
          className="pic-otp-input"
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={digit}
          placeholder="–"
          onChange={(e) => handleCodeChange(index, e.target.value)}
          onKeyDown={(e) => handleKeyDown(index, e)}
          disabled={loading}
        />
      ))}
    </div>
  )

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <MobileScreenLayout
        title="We sent a text"
        content={
          <form onSubmit={handleMobileSubmit} noValidate>
            <p className="pic-description">
              Enter the code we sent to <span className="pic-phone">{maskPhone(phone)}</span> to verify you are the owner or primary user of this phone number.
            </p>

            <input
              className="pic-single-input"
              type="text"
              inputMode="numeric"
              maxLength={6}
              value={mobileCode}
              placeholder="Enter 6-digit code"
              onChange={(e) => handleMobileCodeChange(e.target.value)}
              disabled={loading}
              autoComplete="one-time-code"
            />
            {error && <p className="pic-error">{error}</p>}

            <button
              type="submit"
              className="screen-btn-primary screen-btn-full pic-submit"
              disabled={loading || !isMobileCodeComplete}
            >
              {loading ? 'Verifying…' : 'Sign In'}
            </button>

            <p className="pic-trouble">Didn't receive a code?</p>
            <div className="pic-footer-links">
              <button type="button" className="pic-footer-link" onClick={handleResend} disabled={resendLoading || loading}>
                {resendLoading ? 'Sending…' : 'Request New Code'}
              </button>
              <button type="button" className="pic-footer-link" onClick={handleSignInWithPassword} disabled={loading}>
                Sign In With Password &rsaquo;
              </button>
            </div>
          </form>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="pic-page">
      <div className="pic-container">
        <ToyotaLogo />

        <p className="pic-eyebrow">SIGN IN</p>
        <h1 className="pic-title">Sign In with a<br />Temporary Pass Code</h1>
        <p className="pic-description">
          We have sent you a 6-digit temporary access code to your mobile phone number.
        </p>
        {phone && <p className="pic-phone">{phone.replace(/^\+\d{1,3}/, '')}</p>}

        <form onSubmit={handleSubmit} noValidate>
          {otpInputs}
          {error && <p className="pic-error">{error}</p>}

          <button type="button" className="pic-resend" onClick={handleResend} disabled={resendLoading || loading}>
            {resendLoading ? 'Sending…' : 'Request New Code'}
          </button>

          <button
            type="submit"
            className="screen-btn-primary pic-submit"
            disabled={loading || !isCodeComplete}
          >
            {loading ? 'Verifying…' : 'Sign In'}
          </button>
        </form>

        <p className="pic-trouble">Still having trouble?</p>
        <div className="pic-footer">
          <button type="button" className="pic-footer-link" onClick={handleSignInWithPassword} disabled={loading}>
            Sign In With Password &rsaquo;
          </button>
          <button type="button" className="pic-footer-link" onClick={handleTryDifferentSignIn} disabled={loading}>
            Try a Different Sign In &rsaquo;
          </button>
          <a href="https://www.toyota.com/support/contact-us" className="pic-footer-link">
            Support &rsaquo;
          </a>
        </div>
      </div>
    </div>
  )
}
