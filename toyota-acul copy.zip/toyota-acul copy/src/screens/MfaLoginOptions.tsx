import { useState } from 'react'
import MfaLoginOptionsManager from '@auth0/auth0-acul-js/mfa-login-options'
import ToyotaLogo from '../components/ToyotaLogo'
import MobileScreenLayout from '../components/MobileScreenLayout'
import { maskPhone } from '../utils/maskPhone'
import { maskEmail } from '../utils/maskEmail'
import './Screen.css'
import './MfaLoginOptions.css'

interface Props {
  isMobile?: boolean
}

interface FactorItem { type: string; value?: string }

function getFactorLabel(factor: FactorItem, maskedPhone: string, maskedEmail: string): string {
  // Use Auth0-supplied masked value when available, fall back to our own masking
  const phone = factor.value ?? maskedPhone
  const email = factor.value ?? maskedEmail
  switch (factor.type) {
    case 'sms':               return `Text a code to: ${phone}`
    case 'voice':             return `Call me at: ${phone}`
    case 'email':             return `Send code to: ${email}`
    case 'otp':               return 'Use authenticator app'
    case 'push-notification': return 'Use push notification'
    case 'recovery-code':     return 'Use a recovery code'
    case 'webauthn-roaming':  return 'Use a security key'
    case 'webauthn-platform': return 'Use biometrics'
    default:                  return factor.type
  }
}

export default function MfaLoginOptionsScreen({ isMobile }: Props) {
  const manager = new MfaLoginOptionsManager()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const ctx = (window as any).universal_login_context
  const user = ctx?.user ?? {}

  // Factors and pre-masked display values all live in ctx.user
  const enrolledFactorTypes: string[] = Array.isArray(user.enrolled_factors) ? user.enrolled_factors : []
  const enrolledPhones: { id: number; phoneNumber: string }[] = user.enrolled_phone_numbers ?? []
  const enrolledEmails: { id: number; email: string }[] = user.enrolled_emails ?? []

  const maskedPhone = enrolledPhones[0]?.phoneNumber ?? (user.phone_number ? maskPhone(user.phone_number) : '')
  const maskedEmail = enrolledEmails[0]?.email ?? (user.email ? maskEmail(user.email) : '')

  const factors: FactorItem[] = enrolledFactorTypes.map(type => ({ type }))

  const [selected, setSelected] = useState<string>('')
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)

  async function handleNext(e: React.FormEvent) {
    e.preventDefault()
    if (!selected) return
    setError('')
    setLoading(true)
    try {
      await manager.enroll({ action: selected as any })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  async function handleBack() {
    setLoading(true)
    try {
      await manager.returnToPrevious()
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  const factorList = (
    <div className="mlo-factors">
      {factors.map(factor => (
        <label key={factor.type} className={`mlo-option${selected === factor.type ? ' mlo-option--selected' : ''}`}>
          <input
            type="radio"
            name="mfa-factor"
            value={factor.type}
            checked={selected === factor.type}
            onChange={() => setSelected(factor.type)}
            disabled={loading}
            className="mlo-radio"
          />
          <span className="mlo-option-label">
            {getFactorLabel(factor, maskedPhone, maskedEmail)}
          </span>
        </label>
      ))}
    </div>
  )

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    return (
      <MobileScreenLayout
        title="Select an option"
        content={
          <form onSubmit={handleNext} noValidate>
            <p className="mlo-description">
              Your security is important to us. Please select an option below to verify your identity.
            </p>
            {factorList}
            {error && <p className="mlo-error">{error}</p>}
            <button
              type="submit"
              className="screen-btn-primary screen-btn-full mlo-next"
              disabled={loading || !selected}
            >
              {loading ? 'Please wait…' : 'Next Step'}
            </button>
            <button type="button" className="mlo-help" onClick={handleBack} disabled={loading}>
              Get help with login
            </button>
          </form>
        }
      />
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  return (
    <div className="mlo-page">
      <div className="mlo-container">
        <ToyotaLogo />

        <h1 className="mlo-title">Select an option</h1>
        <p className="mlo-description">
          Your security is important to us. Please select an option below to verify your identity.
        </p>

        <form onSubmit={handleNext} noValidate>
          {factorList}
          {error && <p className="mlo-error">{error}</p>}

          <div className="mlo-actions">
            <button type="button" className="screen-btn-outline mlo-back" onClick={handleBack} disabled={loading}>
              Get help with login
            </button>
            <button
              type="submit"
              className="screen-btn-primary mlo-next"
              disabled={loading || !selected}
            >
              {loading ? 'Please wait…' : 'Next Step'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
