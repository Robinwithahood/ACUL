import { useState, useRef, useEffect } from 'react'
import LoginId from '@auth0/auth0-acul-js/login-id'
import ScreenLayout from '../components/ScreenLayout'
import MobileScreenLayout from '../components/MobileScreenLayout'
import FloatingInput from '../components/FloatingInput'
import SSOButtons from '../components/SSOButtons'
import LoadingOverlay from '../components/LoadingOverlay'
import steeringWheel from '../assets/steering-wheel.png'
import { CLIENT_ERR } from '../utils/errors'
import './Screen.css'
import './LoginId.css'

const COUNTRY_CODES = [
  { code: '+1',  label: '+1' },
  { code: '+52', label: '+52' },
  { code: '+91', label: '+91' }
]

interface Props {
  isMobile?: boolean
}

const SIGNUP_URL = import.meta.env.VITE_SIGNUP_URL as string | undefined

export default function LoginIdScreen({ isMobile }: Props) {
  const manager = new LoginId()
  const errors = manager.getErrors()
  const serverError = errors[0]?.message ?? ''

  const [username, setUsername] = useState('')
  const [countryCode, setCountryCode] = useState('+1')
  const [isPhoneMode, setIsPhoneMode] = useState(false)
  const [error, setError] = useState(serverError)
  const [loading, setLoading] = useState(false)

  const phoneInputRef = useRef<HTMLInputElement>(null)

  // Re-focus the phone input when phone mode activates (FloatingInput unmounts → phone input mounts)
  useEffect(() => {
    if (isPhoneMode && phoneInputRef.current) {
      const el = phoneInputRef.current
      el.focus()
      // Place cursor at end of existing value
      const len = el.value.length
      el.setSelectionRange(len, len)
    }
  }, [isPhoneMode])

  function isPhoneNumber(input: string): boolean {
    return /^\+?[\d\s\-().]{7,}$/.test(input.trim()) && /\d{7,}/.test(input.replace(/\D/g, ''))
  }

  function handleUsernameChange(value: string) {
    setUsername(value)
    const looksLikePhone = /^\d/.test(value.trim()) && value.replace(/\D/g, '').length >= 4
    setIsPhoneMode(looksLikePhone)
  }

  async function handleNext(e: React.FormEvent) {
    e.preventDefault()
    if (!username.trim()) {
      setError(CLIENT_ERR)
      return
    }
    setError('')
    setLoading(true)
    const isPhone = isPhoneNumber(username)
    const normalized = isPhone && !username.trim().startsWith('+')
      ? `${countryCode}${username.replace(/\D/g, '')}`
      : username.trim()
    try {
      await manager.login({ username: normalized })
    } catch (err: any) {
      setError(err?.message ?? '')
      setLoading(false)
    }
  }

  function getSignupUrl() {
    // Desktop: prefer external SIGNUP_URL, fall back to Auth0 signup link
    const base = SIGNUP_URL || manager.screen.signupLink || ''
    if (!base) return ''
    if (username.trim() && !isPhoneMode) {
      const url = new URL(base)
      url.searchParams.set('email', username.trim())
      return url.toString()
    }
    return base
  }

  function getMobileSignupUrl() {
    // Mobile: always use Auth0's universal login signup link
    const base = manager.screen.signupLink || ''
    if (!base) return ''
    if (username.trim() && !isPhoneMode) {
      const url = new URL(base)
      url.searchParams.set('email', username.trim())
      return url.toString()
    }
    return base
  }

  async function handleFederated(connection: string) {
    setLoading(true)
    try {
      await manager.federatedLogin({ connection })
    } catch {
      setLoading(false)
    }
  }

  // ── Mobile layout ──────────────────────────────────────────────
  if (isMobile) {
    const mobileContent = (
      <div>
        <form onSubmit={handleNext} noValidate>
          {isPhoneMode ? (
            <div className="lid-phone-row lid-phone-row--underline">
              <select
                className="lid-country-select lid-country-select--underline"
                value={countryCode}
                onChange={e => setCountryCode(e.target.value)}
                disabled={loading}
                aria-label="Country code"
              >
                {COUNTRY_CODES.map(c => (
                  <option key={c.code} value={c.code}>{c.label}</option>
                ))}
              </select>
              <input
                ref={phoneInputRef}
                className="lid-phone-input lid-phone-input--underline"
                type="tel"
                inputMode="numeric"
                value={username}
                onChange={e => handleUsernameChange(e.target.value)}
                placeholder="Mobile number"
                autoComplete="tel"
                disabled={loading}
              />
            </div>
          ) : (
            <FloatingInput
              id="username"
              label="Email or Mobile Number"
              value={username}
              onChange={handleUsernameChange}
              autoComplete="username webauthn"
              error={error}
              disabled={loading}
              variant="underline"
            />
          )}
          {error && isPhoneMode && <p className="lid-phone-error">{error}</p>}
          {isPhoneMode && (
            <p className="lid-phone-legal">
              By clicking Continue below, you confirm that you are the owner or primary user of this mobile number. You agree to receive automated text messages. Message and data rates may apply.
            </p>
          )}
          <button
            type="submit"
            className="screen-btn-primary screen-btn-full lid-mobile-continue"
            disabled={loading || !username.trim()}
          >
            {loading ? 'Please wait…' : 'Continue'}
          </button>
        </form>

        <div className="lid-mobile-or">
          <span className="lid-mobile-or-line" />
          <span className="lid-mobile-or-text">OR</span>
          <span className="lid-mobile-or-line" />
        </div>

        <div className="lid-mobile-sso">
          <button className="lid-sso-btn" onClick={() => handleFederated('apple')} disabled={loading} type="button">
            <AppleIcon /> Continue with Apple
          </button>
          <button className="lid-sso-btn" onClick={() => handleFederated('google-oauth2')} disabled={loading} type="button">
            <GoogleIcon /> Continue with Google
          </button>
          <button className="lid-sso-btn" onClick={() => handleFederated('facebook')} disabled={loading} type="button">
            <FacebookIcon /> Continue with Facebook
          </button>
        </div>

        <p className="lid-mobile-register">
          Don't have an account?{' '}
          <a
            href="#register"
            className="lid-mobile-register-link"
            onClick={(e) => { e.preventDefault(); const link = getMobileSignupUrl(); if (link) window.location.href = link }}
          >
            Register
          </a>
        </p>
      </div>
    )

    return (
      <>
        {loading && <LoadingOverlay />}
        <MobileScreenLayout title="Welcome back" heroImage={steeringWheel} content={mobileContent} />
      </>
    )
  }

  // ── Desktop layout ─────────────────────────────────────────────
  const formContent = (
    <div>
      <p className="screen-subtitle">Use your email or mobile number</p>
      <form onSubmit={handleNext} noValidate>
        {isPhoneMode ? (
          <div className="lid-phone-row">
            <select
              className="lid-country-select"
              value={countryCode}
              onChange={e => setCountryCode(e.target.value)}
              disabled={loading}
              aria-label="Country code"
            >
              {COUNTRY_CODES.map(c => (
                <option key={c.code} value={c.code}>{c.label}</option>
              ))}
            </select>
            <input
              ref={phoneInputRef}
              className="lid-phone-input"
              type="tel"
              inputMode="numeric"
              value={username}
              onChange={e => handleUsernameChange(e.target.value)}
              placeholder="Mobile number"
              autoComplete="tel"
              disabled={loading}
            />
          </div>
        ) : (
          <FloatingInput
            id="username"
            label="Email or mobile number"
            value={username}
            onChange={handleUsernameChange}
            autoComplete="username webauthn"
            error={error}
            disabled={loading}
          />
        )}
        {error && isPhoneMode && <p className="lid-phone-error">{error}</p>}
        {isPhoneMode && (
          <p className="lid-phone-legal">
            By clicking Next Step below, you confirm that you are the owner or primary user of this mobile number. You agree to receive automated text messages. Message and data rates may apply.
          </p>
        )}
        <div className="screen-actions">
          <button
            type="button"
            className="screen-btn-outline"
            disabled={loading}
            onClick={() => { const link = getSignupUrl(); if (link) window.location.href = link }}
            style={{ borderRadius: '18px' }}
          >
            Create Account
          </button>
          <button
            type="submit"
            className="screen-btn-primary"
            disabled={loading || !username.trim()}
            style={{ borderRadius: '18px' }}
          >
            Next Step
          </button>
        </div>
      </form>
      <p className="screen-hint" style={{ marginTop: '16px' }}>
        You can use your My Lexus or My Toyota or SmartPath account information to log in.
      </p>
    </div>
  )

  const footer = (
    <>
      <a href="https://www.toyota.com/support/contact-us" className="screen-footer-link">Support &rsaquo;</a>
    </>
  )

  return (
    <>
      {loading && <LoadingOverlay />}
      <ScreenLayout
        title="Sign in"
        left={formContent}
        right={
          <SSOButtons
            onApple={() => handleFederated('apple')}
            onGoogle={() => handleFederated('google-oauth2')}
            onFacebook={() => handleFederated('facebook')}
            disabled={loading}
          />
        }
        footer={footer}
      />
    </>
  )
}

function AppleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
    </svg>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  )
}

function FacebookIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
      <path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z" fill="#1877F2"/>
    </svg>
  )
}
