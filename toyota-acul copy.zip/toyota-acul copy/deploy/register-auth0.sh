#!/usr/bin/env bash
# Step 2 of 2: Register CDN asset URLs with Auth0 via PATCH /api/v2/prompts/rendering.
# Reads CDN URLs from .cdn-urls (written by upload-cdn.sh).
#
# Prerequisites:
#   export AUTH0_DOMAIN=sb-tmna.tmna-sb-1.auth0app.com
#   export AUTH0_MGMT_TOKEN=<Management API token with update:prompts scope>
#   .cdn-urls must exist (run upload-cdn.sh first)

set -euo pipefail

DOMAIN="${AUTH0_DOMAIN:?Set AUTH0_DOMAIN}"
TOKEN="${AUTH0_MGMT_TOKEN:?Set AUTH0_MGMT_TOKEN}"

if [[ ! -f .cdn-urls ]]; then
  echo "ERROR: .cdn-urls not found. Run ./deploy/upload-cdn.sh first."
  exit 1
fi

source .cdn-urls

echo "==> Registering with Auth0 tenant: $DOMAIN"
echo "    JS:  $JS_CDN_URL"
echo "    CSS: $CSS_CDN_URL"

PAYLOAD=$(python3 - <<PYEOF
import json

js_url    = "$JS_CDN_URL"
# Support multiple CSS files (space-separated CSS_CDN_URLS, fallback to CSS_CDN_URL)
css_urls_str = "$CSS_CDN_URLS".strip() or "$CSS_CDN_URL"
css_urls = css_urls_str.split()

head_tags = [
    {
        "tag": "link",
        "attributes": {
            "rel": "stylesheet",
            "href": u
        },
        "content": ""
    }
    for u in css_urls
]
head_tags.append({
    "tag": "script",
    "attributes": {
        "src": js_url,
        "type": "module"
    },
    "content": ""
})

screens = [
    {"prompt": "login-id",                       "screen": "login-id"},
    {"prompt": "login-password",                 "screen": "login-password"},
    {"prompt": "signup-id",                      "screen": "signup-id"},
    {"prompt": "signup-password",                "screen": "signup-password"},
    {"prompt": "email-identifier-challenge",     "screen": "email-identifier-challenge"},
    {"prompt": "phone-identifier-challenge",      "screen": "phone-identifier-challenge"},
    {"prompt": "login-passwordless",             "screen": "login-passwordless-sms-otp"},
    {"prompt": "mfa",                            "screen": "mfa-login-options"},
    {"prompt": "mfa-sms",                        "screen": "mfa-sms-challenge"},
    {"prompt": "mfa-sms",                        "screen": "mfa-sms-enrollment"},
    {"prompt": "mfa-email",                      "screen": "mfa-email-challenge"},
    {"prompt": "mfa-phone",                      "screen": "mfa-phone-challenge"},
    {"prompt": "reset-password",                 "screen": "reset-password-request"},
    {"prompt": "reset-password",                 "screen": "reset-password-email"},
    {"prompt": "reset-password",                 "screen": "reset-password"},
    {"prompt": "reset-password",                 "screen": "reset-password-error"},
    {"prompt": "reset-password",                 "screen": "reset-password-success"},
    {"prompt": "brute-force-protection",          "screen": "brute-force-protection-unblock"},
    {"prompt": "brute-force-protection",          "screen": "brute-force-protection-unblock-success"},
]

configs = [
    {
        "prompt": s["prompt"],
        "screen": s["screen"],
        "rendering_mode": "advanced",
        "default_head_tags_disabled": False,
        "use_page_template": True,
        "head_tags": head_tags
    }
    for s in screens
]

print(json.dumps({"configs": configs}, indent=2))
PYEOF
)

RESPONSE=$(curl -s -w "\n__STATUS__%{http_code}" \
  -L -g -X PATCH \
  --url "https://$DOMAIN/api/v2/prompts/rendering" \
  --header "Authorization: Bearer $TOKEN" \
  --header "Content-Type: application/json" \
  --header "Accept: application/json" \
  --data "$PAYLOAD")

BODY=$(echo "$RESPONSE" | sed '$d')
STATUS=$(echo "$RESPONSE" | tail -1 | sed 's/__STATUS__//')

echo "==> HTTP $STATUS"

if [[ "$STATUS" == "200" || "$STATUS" == "201" ]]; then
  echo "==> SUCCESS. Screens configured:"
  echo "    - login-id / login-id"
  echo "    - login-password / login-password"
  echo "    - signup-id / signup-id"
  echo "    - signup-password / signup-password"
  echo "    - email-identifier-challenge / email-identifier-challenge"
  echo "    - phone-identifier-challenge / phone-identifier-challenge"
  echo "    - login-passwordless / login-passwordless-sms-otp"
  echo "    - mfa-sms / mfa-sms-challenge"
  echo "    - mfa-sms / mfa-sms-enrollment"
  echo "    - reset-password / reset-password-request"
  echo "    - reset-password / reset-password-email"
  echo ""
  echo "    Open Auth0 Dashboard > Branding > Universal Login to preview."
else
  echo "==> ERROR:"
  echo "$BODY" | python3 -m json.tool 2>/dev/null || echo "$BODY"
  echo ""
  echo "Common causes:"
  echo "  403 - Token missing 'update:prompts' scope"
  echo "  404 - ACUL not enabled on this tenant"
  exit 1
fi
