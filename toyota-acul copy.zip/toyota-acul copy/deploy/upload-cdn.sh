#!/usr/bin/env bash
# Step 1 of 2: Build ACUL bundle and upload assets to CDN.
# Outputs CDN URLs to .cdn-urls (consumed by register-auth0.sh).
#
# Configure for your CDN by setting one of these provider blocks:
#
# --- AWS S3 + CloudFront ---
#   export CDN_PROVIDER=s3
#   export CDN_BUCKET=your-bucket-name
#   export CDN_BASE_URL=https://d1234abcd.cloudfront.net   # or custom domain
#   export AWS_REGION=us-east-1
#   # AWS credentials via ~/.aws/credentials or env vars
#
# --- Azure Blob Storage ---
#   export CDN_PROVIDER=azure
#   export CDN_BUCKET=your-container-name
#   export CDN_BASE_URL=https://youraccount.blob.core.windows.net/your-container
#   export AZURE_STORAGE_ACCOUNT=youraccount
#   export AZURE_STORAGE_KEY=yourkey
#
# --- GCP Cloud Storage ---
#   export CDN_PROVIDER=gcp
#   export CDN_BUCKET=your-bucket-name
#   export CDN_BASE_URL=https://storage.googleapis.com/your-bucket
#   # gcloud auth must be configured
#
# --- Cloudflare R2 (uses S3-compatible API) ---
#   export CDN_PROVIDER=r2
#   export CDN_BUCKET=your-bucket-name
#   export CDN_BASE_URL=https://your-custom-domain.com
#   export CF_ACCOUNT_ID=your-account-id
#   export AWS_ACCESS_KEY_ID=your-r2-access-key
#   export AWS_SECRET_ACCESS_KEY=your-r2-secret-key

set -euo pipefail

CDN_PROVIDER="${CDN_PROVIDER:?Set CDN_PROVIDER (s3 | azure | gcp | r2)}"
CDN_BUCKET="${CDN_BUCKET:?Set CDN_BUCKET}"
CDN_BASE_URL="${CDN_BASE_URL:?Set CDN_BASE_URL (public root URL of your bucket)}"
CDN_PATH_PREFIX="${CDN_PATH_PREFIX:-toyota-acul}"  # folder inside bucket

echo "==> Building ACUL bundle..."
rm -rf dist/
npm run build

# Identify the ACUL entry chunk. We parse the filename from index.html but strip any
# CDN base prefix that Vite may have embedded (when base= is set at build time).
RAW_JS=$(grep -o 'acul[^"]*\.js' dist/index.html | head -1)
JS_ENTRY_FILENAME=$(basename "$RAW_JS")

# Read ALL CSS filenames referenced in index.html (Vite can produce multiple CSS chunks)
CSS_FILENAMES=()
while IFS= read -r raw_css; do
  CSS_FILENAMES+=("$(basename "$raw_css")")
done < <(grep -o 'acul[^"]*\.css' dist/index.html | sort -u)

if [[ -z "$JS_ENTRY_FILENAME" || ${#CSS_FILENAMES[@]} -eq 0 ]]; then
  echo "ERROR: Built assets not found in dist/"
  exit 1
fi

echo "==> Entry JS:  $JS_ENTRY_FILENAME"
for f in "${CSS_FILENAMES[@]}"; do echo "==> CSS:       $f"; done

upload() {
  local local_file="$1"
  local remote_key="$CDN_PATH_PREFIX/$(basename "$local_file")"
  local content_type="$2"

  echo "==> Uploading $local_file → $CDN_PROVIDER://$CDN_BUCKET/$remote_key"

  case "$CDN_PROVIDER" in
    s3)
      aws s3 cp "$local_file" "s3://$CDN_BUCKET/$remote_key" \
        --content-type "$content_type" \
        --cache-control "public, max-age=31536000, immutable" \
        --region "${AWS_REGION:-us-east-1}"
      ;;
    azure)
      az storage blob upload \
        --account-name "$AZURE_STORAGE_ACCOUNT" \
        --account-key "$AZURE_STORAGE_KEY" \
        --container-name "$CDN_BUCKET" \
        --name "$remote_key" \
        --file "$local_file" \
        --content-type "$content_type" \
        --overwrite
      ;;
    gcp)
      gsutil -h "Content-Type:$content_type" \
             -h "Cache-Control:public, max-age=31536000, immutable" \
        cp "$local_file" "gs://$CDN_BUCKET/$remote_key"
      ;;
    r2)
      aws s3 cp "$local_file" "s3://$CDN_BUCKET/$remote_key" \
        --content-type "$content_type" \
        --cache-control "public, max-age=31536000, immutable" \
        --endpoint-url "https://${CF_ACCOUNT_ID}.r2.cloudflarestorage.com"
      ;;
    *)
      echo "ERROR: Unknown CDN_PROVIDER '$CDN_PROVIDER'. Use: s3 | azure | gcp | r2"
      exit 1
      ;;
  esac
}

# Upload ALL acul.* chunks so relative imports resolve (JS, CSS, images).
for f in dist/acul.*.js;  do upload "$f" "application/javascript"; done
for f in dist/acul.*.png; do [[ -f "$f" ]] && upload "$f" "image/png";  done
for f in dist/acul.*.jpg; do [[ -f "$f" ]] && upload "$f" "image/jpeg"; done
for f in dist/acul.*.svg; do [[ -f "$f" ]] && upload "$f" "image/svg+xml"; done
for css_name in "${CSS_FILENAMES[@]}"; do upload "dist/$css_name" "text/css"; done

JS_CDN_URL="$CDN_BASE_URL/$CDN_PATH_PREFIX/$JS_ENTRY_FILENAME"

CSS_CDN_URLS_ARRAY=()
for css_name in "${CSS_FILENAMES[@]}"; do
  CSS_CDN_URLS_ARRAY+=("$CDN_BASE_URL/$CDN_PATH_PREFIX/$css_name")
done
CSS_CDN_URL="${CSS_CDN_URLS_ARRAY[0]}"          # primary (first) — backward compat
CSS_CDN_URLS="${CSS_CDN_URLS_ARRAY[*]}"         # all URLs, space-separated

# Write URLs to file so register-auth0.sh can consume them
cat > .cdn-urls <<EOF
JS_CDN_URL=$JS_CDN_URL
CSS_CDN_URL=$CSS_CDN_URL
CSS_CDN_URLS="$CSS_CDN_URLS"
EOF

echo ""
echo "==> Uploaded:"
echo "    JS:  $JS_CDN_URL"
for url in "${CSS_CDN_URLS_ARRAY[@]}"; do echo "    CSS: $url"; done
echo ""
echo "==> Run ./deploy/register-auth0.sh to configure Auth0."
